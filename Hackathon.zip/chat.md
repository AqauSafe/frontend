# WhatsApp Chat Export: Hackathon
Export date: November 11, 2026 at 12:47 AM

---

## October 10, 2026

[2:46 AM] **Katim:** Good morning guys.
Any name suggestions for our team?

[6:12 AM] **You:**
> _Katim: Good morning guys.
Any name suggestions for our team?_
Hmmmm

[6:13 AM] **You:**
> _Katim: Good morning guys.
Any name suggestions for our team?_
nope

[12:16 PM] **ArRazaq.:**
> _Katim: Good morning guys.
Any name suggestions for our team?_
Blue-Tech Automation

[12:25 PM] **Katim:** Good day guys.
The team is complete already.
Please let us introduce ourselves so that we know who we're working with.

[12:28 PM] **Katim:** I am Umukatim Abdul, though you can call me Katim.
I am In mechatronics Engineering department.
I'm looking forward to working with you guys.

[12:33 PM] **+234 806 158 8349:** I'm Shemkai Yod
Currently in the Information and Communication Engineering department 
Also looking forward to working with you all

[12:43 PM] **You:**
> _Katim: I am Umukatim Abdul, though you can call me Katim.
I am In mechatronics Engineering department.
I'm looking forward to working with you guys._
[Sticker]

[1:34 PM] **ArRazaq.:** [Document] NIMASA-BEAP PUBLIC NOTICE  CALL FOR APPLICATIONS  NIMASA NATIONAL INNOVATION HACKATHON 2026  _01-1.pdf

[1:34 PM] **ArRazaq.:** [Document] pasted-image-1789211877963-j2hqjk45_copy.pdf

[1:37 PM] **ArRazaq.:** Good afternoon, I'm AbdulRazaq you can call me AB, from mechatronics engineering department,let's build something impactful.

[1:39 PM] **ArRazaq.:**
> _ArRazaq.: Document: NIMASA-BEAP PUBLIC NOTICE  CALL FOR APPLICATIONS  NIMASA NATIONAL INNOVATION HACKATHON 2026  _01-1.pdf_
If you haven't already viewed, this is the explanation scope of the hackathon, I'd advise y'all view it briefly to know what track we're on.

[1:51 PM] **ArRazaq.:** **Poll: What time should we schedule an intro meeting  today ? - we don't have much time 🕔, the meeting would briefly convey what the hackathon is about and host ideas for us to start immediately🏃🏼💨.**
- 3:00pm
- 5:00pm
- 8:00pm
- In between (5:00-8:00) pm

[2:08 PM] **ArRazaq.:** @all

[2:15 PM] **JOEL:** My greetings to you all.
I'm Joel from Mechatronics Engineering Department.
It's my pleasure working with you guys.

[3:17 PM] **You:** I'm Kazahyet Astro Bitrus, Mechatronics Engineering Department.
Looking forward to working with you all🙂‍↕️

[3:28 PM] **ArRazaq.:**
> _ArRazaq.: [poll_creation]_
5:30 pm it is , y'all should get something to jot with If possible.

[3:29 PM] **You:**
> _ArRazaq.: 5:30 pm it is , y'all should get something to jot with If possible._
[Sticker]

[3:29 PM] **You:** Might be absent sha

[3:37 PM] **ArRazaq.:** Please make sure you review the docs I sent prev...else you can get their website from there and use it to check info.🦈

@all 

Look forward to getting started from the meeting.

[3:38 PM] **ArRazaq.:**
> _You: Might be absent sha_
Updated to 5:30

[3:39 PM] **ArRazaq.:** I hope we'll all make It 🙏🏼

[3:42 PM] **JOEL:** Sorry, I may be 30 minutes late because I'll be doing something during that time.

[3:44 PM] **You:**
> _ArRazaq.: Updated to 5:30_
[Sticker]

[5:28 PM] **ArRazaq.:**
> _You: Sticker_
[Sticker]

[5:28 PM] **ArRazaq.:** Good evening guys @all

[5:29 PM] **Katim:** https://call.whatsapp.com/video/G9eZovQBeMIGOAmXqBan2m

[5:29 PM] **ArRazaq.:** https://nbeap.nimasa.gov.ng

[5:30 PM] **ArRazaq.:** Would it make sense if we used voice note and normal text so that those who are not available can still see what we were discussing?

[5:31 PM] **Katim:** Okay.
Let's give it a try.

[5:32 PM] **ArRazaq.:** Good evening @all

[5:35 PM] **+234 806 158 8349:**
> _ArRazaq.: Would it make sense if we used voice note and normal text so that those who are not available can still see what we were discussing?_
Yh
Texts and voice would be alright

[5:35 PM] **ArRazaq.:** _Waiting for this message. This may take a while._

[5:35 PM] **+234 806 158 8349:**
> _ArRazaq.: Good evening @all_
Evening

[5:36 PM] **ArRazaq.:** Ok so what is going on ? , what kind of hackathon is this ??

[5:39 PM] **Katim:** [Voice message]

[5:43 PM] **ArRazaq.:** [Voice message]

[5:43 PM] **ArRazaq.:** [Image]

[5:44 PM] **ArRazaq.:** [Voice message]

[5:44 PM] **ArRazaq.:** [Voice message]

[5:45 PM] **ArRazaq.:** [Image]

[5:46 PM] **ArRazaq.:** [Voice message]

[5:47 PM] **ArRazaq.:** [Image]

[5:47 PM] **ArRazaq.:** [Voice message]

[5:50 PM] **ArRazaq.:** [Voice message]

[5:50 PM] **ArRazaq.:** [Voice message]

[5:58 PM] **Katim:** [Voice message]

[6:00 PM] **You:** Sorry I'm late

[6:00 PM] **ArRazaq.:**
> _You: Sorry I'm late_
[Sticker]

[6:01 PM] **You:**
> _ArRazaq.: Sticker_
[Sticker]

[6:02 PM] **+234 806 158 8349:** What i think is that before we finalize an idea, we should first consider different existing problems and how our proposed solution would solve that problem exceptionally well
Because for our idea to work, it needs to solve an important issue people are willing to pay for

[6:02 PM] **ArRazaq.:**
> _+234 806 158 8349: What i think is that before we finalize an idea, we should first consider different existing problems and how our proposed solution would solve that problem exceptionally well
Because for our idea to work, it needs to solve an important issue people are willing to pay for_
Normal

[6:02 PM] **ArRazaq.:** _This message was deleted_

[6:03 PM] **ArRazaq.:**
> _Katim: Voice message_
[Voice message]

[6:07 PM] **You:**
> _Katim: Voice message_
I feel many people are going to go for that idea so if we're going down that track we have to come up with a very very solid idea

[6:08 PM] **ArRazaq.:**
> _You: I feel many people are going to go for that idea so if we're going down that track we have to come up with a very very solid idea_
I think so 2

[6:11 PM] **ArRazaq.:** Does anyone have any idea ? @all

[6:14 PM] **+234 806 158 8349:**
> _ArRazaq.: Does anyone have any idea ? @all_
Not at the moment
Research is needed to understand what we need to do and come up with something better, same with time also

[6:15 PM] **You:**
> _ArRazaq.: Does anyone have any idea ? @all_
One idea I have is towards the Aqauculture track

[6:15 PM] **You:** Cuz in Nigeria any agriculture or food related innovation would have a big impact and sell out well

[6:16 PM] **ArRazaq.:**
> _You: One idea I have is towards the Aqauculture track_
Please share

[6:20 PM] **You:**
> _ArRazaq.: Please share_
[Voice message]

[6:25 PM] **ArRazaq.:**
> _You: Voice message_
Noted... ai told me about something like this one time

[6:25 PM] **Katim:** [Voice message]

[6:26 PM] **JOEL:** I believe you guys should send your ideas and the tracks of your choice as a message because voice note is somewhat tedious and for easy referencing.

[6:26 PM] **ArRazaq.:**
> _Katim: Voice message_
My track is on Majorly 5, but it spreads to 1&2..5 sha

[6:28 PM] **ArRazaq.:**
> _Katim: Voice message_
Ok as katim said let's divide ourselves for the 2 day research spanning selected tracks... we'd come back Monday evening for a meeting

[6:28 PM] **JOEL:** AbdulRazak :
Track 1, 2 and 5

AbdulKatim:
Track 6

Astro:
Track 7

If I am not mistaken.

[6:28 PM] **You:**
> _ArRazaq.: Noted... ai told me about something like this one time_
[Sticker]

[6:29 PM] **You:**
> _ArRazaq.: Noted... ai told me about something like this one time_
Me sef I be AI😂

[6:29 PM] **ArRazaq.:**
> _You: Me sef I be AI😂_
[Sticker]

[6:29 PM] **ArRazaq.:**
> _JOEL: AbdulRazak :
Track 1, 2 and 5

AbdulKatim:
Track 6

Astro:
Track 7

If I am not mistaken._
AbdulRazak :
Track 5

AbdulKatim:
Track 6

Astro:
Track 7

If I am not mistaken.

[6:30 PM] **ArRazaq.:** Ok as katim said let's divide ourselves for the 2 day research spanning selected tracks... we'd come back Monday evening for a meeting

[6:30 PM] **Katim:** Abdul should be taken as track 5 though

[6:33 PM] **JOEL:** I believe it's best to select tracks of our core interest for faster research and to prevent overly divided attention.

[6:35 PM] **+234 806 158 8349:** _This message was deleted_

[6:35 PM] **+234 806 158 8349:** _This message was deleted_

[6:35 PM] **JOEL:** Now the listed tracks are:
1, 2, 5, 6, 7
We can't possibly do all of them because 2 could be so demanding that you may not have much attention for the others.

[6:36 PM] **ArRazaq.:**
> _JOEL: Now the listed tracks are:
1, 2, 5, 6, 7
We can't possibly do all of them because 2 could be so demanding that you may not have much attention for the others._
Ok forget about 1 and 2..it's just 5,6,7

[6:36 PM] **JOEL:**
> _ArRazaq.: Ok forget about 1 and 2..it's just 5,6,7_
Could you please  give us your reasons?

[6:37 PM] **ArRazaq.:**
> _JOEL: Could you please  give us your reasons?_
My idea was about security and digitization simultaneously, but however it was Majorly digitization and Smart solution so track 5

[6:39 PM] **ArRazaq.:** @~Time @JOEL do you have any suggested tracks before we move on ?

[6:40 PM] **+234 806 158 8349:** I'll work with what we decide

[6:43 PM] **JOEL:** In my opinion
Track 1 talks about building systems that controls and coordinates transportation on sea or basically between sea ports.
Track 2 is also great one that deals with security and surveillance. It ranges from CCTV camera or Motion detection devices used in offices or checkstations to Drones that could measure the landscape of an area or for real live tracking of a sea vessel (Ship, boats) etc.

[6:44 PM] **JOEL:**
> _ArRazaq.: @~Time @JOEL do you have any suggested tracks before we move on ?_
I am just building on what you guys suggested and why it could be worth considering.

[6:46 PM] **JOEL:** It boils down to understanding what we want to do before doing it so we don't quit when we encounter a challenge.

[6:47 PM] **ArRazaq.:** Great it's decided then track 5,6,7.....5 people 3 tracks

[6:53 PM] **JOEL:** I believe track 5 is constrained to only the sea port alone. That is, ensuring the cargo or goods are set in the right place, also if they are complete, maybe verification if the fees has been paid and the goods can be transported. Those I believe and more are activities carried out  in the seaport.

[6:56 PM] **ArRazaq.:** Here's the game 

Instead of 2 days we would do 3...each day for a track

5 of us would get findings on 1 track each day, would scout problems on each track and check feasibility and competitive edge.

Have a lovely day, if you have any questions or additions regardless of the time , please share thanks

@all

[6:56 PM] **ArRazaq.:** We would have a meeting each of these 3 days anything after is actually building the prototype

[6:57 PM] **Katim:** So we should know what track for what day

[6:58 PM] **ArRazaq.:**
> _JOEL: I believe track 5 is constrained to only the sea port alone. That is, ensuring the cargo or goods are set in the right place, also if they are complete, maybe verification if the fees has been paid and the goods can be transported. Those I believe and more are activities carried out  in the seaport._
From what I understood they said it's digitization and Smart solutions spanning port operations to customs and even tracking so it's broad

[6:59 PM] **ArRazaq.:** After reviewing it I realized that it doesn't really contain 1 and 2

[7:07 PM] **JOEL:** 6 and 7 are also worth considering.
The former talks about how waste can be managed and how you could also redirect marine waste to producing useful things.
The latter talks about how one could improve the state of water bodies and cause it to be an environment that encourages  fishery.
So they are all good

[7:08 PM] **JOEL:**
> _ArRazaq.: From what I understood they said it's digitization and Smart solutions spanning port operations to customs and even tracking so it's broad_
Okay, It's fine.

[7:15 PM] **ArRazaq.:** Ok we would still take 5, if after research we discover something interesting it would be noted..when researching also note the ideas @Katim ,@ZXCHAM @myself

Suggested to note if it's a good idea

Already I can say that I did some research previously concerning my idea and @ZXCHAM idea from googling, news and ai chatting..

Ai told me that fish do die because of oxygen and farmers loose a lot of fish but don't know what's happening and that because of how hard my idea is ai vision, embedded systems, full stack web app it would be hard for most teams to go there, 

watching teen titans and other shows they had a particular episode where they were talking about cleaning beaches/oceans and for technology I don't know how we are going to make something that can clean a big wide area.


Regardless this is why we are going to do deep research of 5,6,7 to know which one is more feasible and competitive.

Thank you all for showing up 🙌🏼, let's build something great.

@all

[7:16 PM] **ArRazaq.:** Sunday 
Track 5 - Digitization Smart 
port Solutions 

Monday
Track 6 - Marine Waste Management and Blue collar economy 

Tuesday
Track 7 - Aquaculture and sustainable fisheries

---

## October 11, 2026

[3:21 AM] __ArRazaq. changed the group icon__

[11:11 AM] **ArRazaq.:** Good morning Guys , today we should do research about track 5, discover existing solutions and bridge what it's lacking such as accessibility 🫪.

[11:11 AM] **ArRazaq.:** **Poll: When Should Today's Meeting Occur 🕴🏼?**
- 2:00pm🦈
- 5:00pm🦦
- 8:00pm🐠
- Between (5:00-8:00) pm 🐡

[11:11 AM] **ArRazaq.:** @ZXCHAM @JOEL @Katim @~Time 

@all 🙂

[3:14 PM] **ArRazaq.:** Ok it's official then we're meeting at 5:20 pm @all

[3:27 PM] **You:** Aiit

[4:26 PM] **JOEL:** A very Good afternoon to you guys and Happy Sunday!

[4:29 PM] **JOEL:** Please, could I invite or add another person to this group?
He is a marine engineering student.

[4:31 PM] **You:**
> _JOEL: A very Good afternoon to you guys and Happy Sunday!_
[Sticker]

[4:31 PM] **You:**
> _JOEL: Please, could I invite or add another person to this group?
He is a marine engineering student._
@Katim ??

[4:33 PM] **Katim:**
> _JOEL: Please, could I invite or add another person to this group?
He is a marine engineering student._
Uhmm.
We will like to know what his strengths and weaknesses are because the agreed number for the team was 4 then it changed to 5 .
So it depends.

[4:33 PM] **Katim:** Good evening Guys

[4:35 PM] **Katim:**
> _Katim: Uhmm.
We will like to know what his strengths and weaknesses are because the agreed number for the team was 4 then it changed to 5 .
So it depends._
All I'm saying is I would love to have a word with him. Maybe and anyone interested in being on the call too

[4:36 PM] **JOEL:** Could we have a voice call meeting? I would then invite him

[4:37 PM] **JOEL:**
> _Katim: Uhmm.
We will like to know what his strengths and weaknesses are because the agreed number for the team was 4 then it changed to 5 .
So it depends._
It's fine
I understand.

[4:38 PM] **Katim:** Okay sure

[5:09 PM] **ArRazaq.:** _This message was deleted_

[5:10 PM] **ArRazaq.:** Good evening @all

[5:12 PM] **Katim:**
> _ArRazaq.: Good evening @all_
Good evening.
Will our meeting be like yesterday?

[5:13 PM] **ArRazaq.:**
> _Katim: Good evening.
Will our meeting be like yesterday?_
Yes I think it should so that we can reference the messages later

[5:14 PM] **Katim:**
> _ArRazaq.: Yes I think it should so that we can reference the messages later_
Okay sure 👍

[5:14 PM] **You:**
> _ArRazaq.: Good evening @all_
Good eveningg

[5:15 PM] **Katim:** But the only thing we will need for every meeting should be the conclusions and next step.

[5:19 PM] **ArRazaq.:**
> _Katim: But the only thing we will need for every meeting should be the conclusions and next step._
And also intel

[5:19 PM] **JOEL:** could we do something where we are able to engage in a group call within a said interval. I believe this helps to build our communication and reasoning as we will be presentino our ideas within a short time. Then our final thought would be written after the call like other official meetings do

[5:20 PM] **ArRazaq.:**
> _JOEL: could we do something where we are able to engage in a group call within a said interval. I believe this helps to build our communication and reasoning as we will be presentino our ideas within a short time. Then our final thought would be written after the call like other official meetings do_
Aiit then @Katim is you're network strong?

[5:20 PM] **ArRazaq.:** Let's start the vid call

[5:20 PM] **You:**
> _ArRazaq.: Let's start the vid call_
[Sticker]

[5:21 PM] **Katim:** https://call.whatsapp.com/video/NormRMWQZ4wlw8XQXuLFDm

[5:22 PM] **Katim:** We are in already guys

[5:22 PM] **JOEL:** Video call?..

[5:23 PM] **Katim:** No not Really.

[5:32 PM] **+234 806 158 8349:** Good evening @all 
This is what i think of track 5

Nigeria's port authorities are actively pursuing digitalisation and modernisation. This makes port technology a relevant area for innovation. Existing industrial research also demonstrates the practical value of condition monitoring and fault detection in port equipment.

What weakens our current proposal?

Equipment monitoring and predictive maintenance already exist. We cannot claim novelty simply because our system uses an ESP32, IoT, sensors or AI.

What would strengthen it?

We need evidence of a specific customer problem, a clear advantage over existing alternatives, a working prototype and repeatable test results.

[5:54 PM] **+234 806 158 8349:** One idea i had on track 5

We could develop a simulation software that replicates a port and its operations, including ships, berths, container yards, trucks, and cargo-handling equipment.

The Problem: Port operators face challenges such as congestion, delays, and inefficient resource allocation. Testing operational changes in real ports can be costly and risky.

The Solution:
We could create a virtual port where operators can simulate different scenarios, predict potential problems, and test solutions before implementing them in real life. Using AI and optimisation algorithms, it could recommend better ways to allocate resources, schedule trucks, and manage port operations.

The Goal: To make port operations smarter, more efficient, and cost-effective through simulation and intelligent decision-making.

[5:59 PM] **Katim:**
> _+234 806 158 8349: One idea i had on track 5

We could develop a simulation software that replicates a port and its operations, including ships, berths, container yards, trucks, and cargo-handling equipment.

The Problem: Port operators face challenges such as congestion, delays, and inefficient resource allocation. Testing operational changes in real ports can be costly and risky.

The Solution:
We could create a virtual port where operators can simulate different scenarios, predict potential problems, and test solutions before implementing them in real life. Using AI and optimisation algorithms, it could recommend better ways to allocate resources, schedule trucks, and manage port operations.

The Goal: To make port operations smarter, more efficient, and cost-effective through simulation and intelligent decision-making._
Okay sir.
We have taken note and are discussing it.
We will send feedback as well

[7:23 PM] **ArRazaq.:** > We would be having 3 days to research🔎 across track 6 and track 7, then would meet on Wednesday evening to list the best idea💡 from each track and then vote for the one we would consequently work on seriously.

[7:29 PM] **ArRazaq.:** Ideas for track 5:
1. Document verification system.👈🏼
2. Oil spillage/toxic waste spillage and tracking ship responsible with satellite.😤
3. Software for exporters to show fees upfront.🙂
4. System to check for faults in ship and send alert.👌🏼
5. Virtual Simulation software for port operations.🕴🏼🕴🏼

[7:35 PM] **ArRazaq.:** _This message was deleted_

[7:39 PM] **ArRazaq.:** Just wanted to add that after   the meeting I remembered a event that happened in Nigeria in the 1900s , 

USA navy used submarine to hide in Nigeria waters for months and we're not discovered despite patrols, 

I also saw that recently people see dead fishes floating on the ocean of Nigeria.

[7:43 PM] **ArRazaq.:** The point is , the oil spillage/toxic satellite idea by @JOEL  shouldn't be only limited to the fact but include detecting when invaders are on Nigeria's territory at sea.

Those fishes that float die because of toxic waste usually, and can be picked by harsh fishermen to be sold and consumers would get the side effects.

But this idea has the potential to stop these problems.

@all

[7:44 PM] **You:**
> _ArRazaq.: Just wanted to add that after   the meeting I remembered a event that happened in Nigeria in the 1900s , 

USA navy used submarine to hide in Nigeria waters for months and we're not discovered despite patrols, 

I also saw that recently people see dead fishes floating on the ocean of Nigeria._
Hmm🧎🏾‍♂️

[7:44 PM] **You:** I'll look into those

[7:44 PM] **ArRazaq.:** Go ahead mahn

[7:47 PM] **ArRazaq.:**
> _You: Hmm🧎🏾‍♂️_
It was during Abashas time

[8:05 PM] **JOEL:** I didn't add that instead of using a satellite, we could also use a drone. The question is: can there be a simulated drone and environment?

[8:07 PM] **ArRazaq.:**
> _JOEL: I didn't add that instead of using a satellite, we could also use a drone. The question is: can there be a simulated drone and environment?_
The question is if we're able to use a simulated drone and environment because they are there, like Gazebo.

[8:09 PM] **ArRazaq.:** I forgot to add one idea 🤦🏼

[8:09 PM] **JOEL:**
> _ArRazaq.: The question is if we're able to use a simulated drone and environment because they are there, like Gazebo._
Good.
Here is my research on my own idea:

QUESTION
Do I need to invest money in that satellite prototype. Option 2?

No, you do not need to spend any money on Option 2.
For a hackathon prototype, you do not need to buy commercial satellite images or build any hardware. You can build a highly impressive, winning prototype using entirely free data and clever simulations.
Here is exactly how your team can pull off Option 2 (EcoMaritime Guard) for free:

1. Use 100% Free Satellite Data (No Credit Card Required)

You do not need to pay private satellite companies. The European Space Agency (ESA) provides public access to its Sentinel-1 and Sentinel-2 satellites through free web portals.
• Your developers can use the Copernicus Data Space Ecosystem API to access historical radar imagery of the Nigerian coastline completely free of charge.
• Radar imagery (SAR) is perfect because oil spills look like distinct dark patches against the rough ocean surface, even at night or through heavy clouds.

2. The "Hackathon Shortcut": Use Static Mock Data

If your developers are running out of time during the 24–72 hour sprint, you do not even need a live, real-time satellite connection.
• What to do instead: Download 2 or 3 existing, historical satellite images of an oil spill off the coast of West Africa (or just generic open-ocean images).
• Save these images directly into your project folder as static files.
• When you click "Scan Ocean" on your dashboard during the presentation, have your app load these saved images. This shows the judges exactly how your system works without writing thousands of lines of complex live-streaming code.

3. Use Free Open-Source Tracking Feeds

To match the oil spill with a ship, you need AIS (vessel tracking) data. Premium AIS feeds are expensive, but you can use free, open-source mock data or free developer accounts:
• Your team can download historical vessel tracking datasets (CSV files) from open platforms like Global Fishing Watch or MarineTraffic's free research tiers.
• You can easily simulate a ship's path across your map using a free mapping tool like Leaflet.js or OpenStreetMap.

 The Presenter's Secret: Sell the Vision

The judges at the NIMASA-BEAP hackathon know you only have a few days to build. They do not expect a multi-million naira live satellite system. They want to see:
1. A beautiful Frontend Dashboard (what the NIMASA officer sees).
2. The Logical Flow (Satellite detects spill → Algorithm pulls nearby ship coordinates → NIMASA generates a fine).
Your team can build this entire workflow using Python, React, and free mock data without spending a single Naira.

[8:09 PM] **JOEL:**
> _ArRazaq.: I forgot to add one idea 🤦🏼_
Please, Go ahead!

[8:15 PM] **ArRazaq.:** **Poll: The idea with the less Vote would be discarded for the Wednesday meeting 🦈🦈**
- Document verification system.👈🏼📃
- 2. Oil spillage/toxic waste spillage and tracking ship responsible with satellite🦈📡
- Software for exporters to show fees upfront.🙂📈
- System to check for faults in ship and send alert.👌🏼🔗
- Virtual Simulation software for port operations.🕴🏼🕴🏼🤖
- System integrating machine vision, ai data analysis,hardware for loading/custody monitoring 🫟💉

[8:15 PM] **ArRazaq.:** Sorry about that y'all vote here for Track 5☝🏼

[8:20 PM] **You:**
> _ArRazaq.: [poll_creation]_
[Sticker]

[8:20 PM] **ArRazaq.:**
> _You: Sticker_
[Sticker]

[9:28 PM] **JOEL:** Here is the detailed research for my Idea 1: Automated Vessel (ships) Inspection and Compliance system.


Comprehensive Research: Automated Vessel Inspection & Compliance System (Smart Port State Control)

To give your team a complete overview, let’s do a deep dive into Option 1 (NIMASA AnchorCheck). this research is written so you can easily understand the operational flow and confidently pitch its real-world value to the NIMASA judges.

 1. The Context: The Pre-Docking Paperwork Nightmare

Before any international cargo ship or oil tanker is legally allowed to drop its anchor or tie up at a Nigerian pier (dock), NIMASA inspectors must complete a Port State Control (PSC) audit.

The Manual Bottleneck

By international maritime law, a ship must prove it is safe, sea-worthy, and environmentally compliant. This requires inspecting dozens of legal certificates issued by different global bodies.
• The Current Reality: When a ship arrives in Nigerian waters, it sits idle out at sea (at the anchorage). A shipping agent physically collects paper copies of these certificates, boards a small boat, and brings them to the NIMASA office. Alternatively, NIMASA inspectors have to physically board the ship via pilot ladders.
• The Consequences: A single ship verification can take 24 to 48 hours just sitting on a desk. This creates a massive backlog. While ships wait, importers are slammed with thousands of dollars in demurrage penalties, and Nigeria’s ports gain a global reputation for being slow and expensive.

 2. How the Tech Works: Optical Character Recognition (OCR) & Document Parsing

To eliminate this wait time without spending money, your hackathon prototype will use OCR Engines (like Python’s free Pillow and pytesseract libraries) combined with automated data parsing.
Instead of treating a scanned PDF or a smartphone photo of a certificate as an unreadable picture, the OCR engine analyzes the pixel layout. It identifies lines, blocks, and shapes, translating them into actual text fields (strings) that a computer database can read, calculate, and evaluate.

The Three Core Certificates to Target for Your Prototype:

To keep your hackathon scope manageable, tell your developers to focus on extracting data from just three critical maritime documents:
1. International Tonnage Certificate: Proves the physical weight and carrying capacity of the ship.
2. Safety Management Certificate (SMC): Proves the ship complies with the International Safety Management (ISM) code.
3. International Oil Pollution Prevention (IOPP) Certificate: Proves the ship has operational equipment to prevent ocean pollution.

3. The Optimal Action Plan (The Hackathon Execution Blueprint)

The most optimal action your team can take to build this prototype is to construct a Pre-Arrival Cloud Portal with an Automated Risk-Scoring Verification Engine.

Why should it be carried out this way?

1. Zero-Contact Administration: It shifts the entire verification process from post-arrival (physical and slow) to pre-arrival (digital and instant).
2. Resource Optimization: NIMASA doesn't have enough physical inspectors to board every single ship thoroughly. This system automatically filters out the compliant ships, allowing inspectors to focus 100% of their physical energy on high-risk violators.

Step-by-Step Technical Execution 

[Step 1: Web Portal] ──> [Step 2: Python OCR Engine] ──> [Step 3: Validation Engine] ──> [Step 4: NIMASA Portal]
(Agent Uploads PDFs)       (Reads Text & Expiry Dates)       (Calculates Risk Score)         (Flags Approved vs High-Risk)
1. Step 1: The Pre-Arrival Portal (The Interface):
	• Build a simple web webpage where shipping lines or local port agents log in and input upcoming voyage details. They upload digital scans (PDF/PNG) of the ship’s mandatory safety certificates.
2. Step 2: Automated Data Extraction (The Brain):
	• When a file is uploaded, your backend Python script runs an OCR pass over the document.
	• It uses regex (text pattern matching) to grab specific words. For example, it searches the document for the text "Expiry Date:" or "Valid Until:" and grabs the date characters immediately following it.
3. Step 3: The Risk-Scoring Matrix (The Logic):
	• Your code compares the extracted expiry date against the current date (today's date).
	• It checks a simulated database of blacklisted vessels or unauthorized flags.
	• The Output: It calculates a dynamic Vessel Risk Score. If certificates are valid and the ship has a clean record, it scores Green (Low Risk). If a certificate expires in less than 48 hours, or is already expired, it flashes Red (High Risk).
4. Step 4: The Inspector's Action Terminal (The Value):
	• NIMASA officials view a live list of inbound ships sorted by risk.
	• Green ships receive an Automated Digital Port Clearance Pass instantly via email before they even enter Nigerian waters. Red ships are flagged, locking their clearance status and scheduling a mandatory, physical physical inspection team to meet them the moment they arrive.

4. Why This Wins the NIMASA Hackathon

When presenting this option, frame it as a direct boost to Nigeria's trade infrastructure:
• Massive Congestion Relief: It slashes paperwork processing times from 2 days to less than 2 minutes, allowing ships to dock and unload immediately.
• Anti-Corruption Safeguard: By automating document verification through code, you eliminate the physical back-and-forth negotiations where paperwork can be manually altered or bypassed.
• Global Maritime Alignment: It upgrades NIMASA's operational workflows to match advanced smart ports like Singapore and Rotterdam, vastly improving Nigeria’s ease-of-doing-business index.

[9:31 PM] **JOEL:** It's an addition to what I said during the group call.

[9:59 PM] **JOEL:** WE CAN DO THIS!

---

## October 12, 2026

[9:22 PM] **ArRazaq.:** [Image] @all  Note that it's not necessarily about how complex a project is, judges also score based on feasibility (how easy it is to implement in the real world).

[9:50 PM] **You:**
> _ArRazaq.: Image: @all  Note that it's not necessarily about how complex a project is, judges also score based on feasibility (how easy it is to implement in the real world)._
Just pretend the stickers aren't there🙂‍↕️

---

## October 13, 2026

[11:10 AM] **ArRazaq.:**
> _ArRazaq.: [poll_creation]_
Voting expires tomorrow

[4:23 PM] **ArRazaq.:** [Image]

[4:24 PM] **ArRazaq.:** [Image]

[4:24 PM] **ArRazaq.:** [Image]

[4:24 PM] **ArRazaq.:** @all

[4:48 PM] **ArRazaq.:** [album message]

[4:48 PM] **ArRazaq.:** [Image]

[4:48 PM] **ArRazaq.:** [Image]

[4:48 PM] **ArRazaq.:** [Image]

[4:48 PM] **ArRazaq.:** [Image]

[4:48 PM] **ArRazaq.:** [Image]

[4:48 PM] **ArRazaq.:** Pics of port

[4:49 PM] **ArRazaq.:** I have an idea for a name of our team, "Port Sentries" what do you guys think? 🙂

[8:08 PM] **ArRazaq.:** Guys I'm with someone who works in ports, if you have any suggested questions I should ask please drop...@all

[8:09 PM] **You:**
> _ArRazaq.: Image_
[Sticker]

[8:09 PM] **You:**
> _ArRazaq.: I have an idea for a name of our team, "Port Sentries" what do you guys think? 🙂_
Not bad👌🏾

[8:10 PM] **You:**
> _ArRazaq.: Guys I'm with someone who works in ports, if you have any suggested questions I should ask please drop...@all_
Ask what's a common problem they face

[8:24 PM] **Katim:** [Forwarded] [Audio]

[8:24 PM] **Katim:** This is shem explaining the concept of his idea

[8:47 PM] **JOEL:**
> _ArRazaq.: Guys I'm with someone who works in ports, if you have any suggested questions I should ask please drop...@all_
Really!

[8:55 PM] **JOEL:**
> _Katim: Audio_
That's great!
Training an AI model requires considerable amount of carefully dinstinct datasets, and also for a highly optimised model, it requires time to some extent.

[8:57 PM] **You:**
> _JOEL: That's great!
Training an AI model requires considerable amount of carefully dinstinct datasets, and also for a highly optimised model, it requires time to some extent._
I have Google AI plus sub so we could use my Colab account to train it

[8:59 PM] **JOEL:** _This message was deleted_

[9:01 PM] **JOEL:** PROJECT'S ROADMAP

1) Research on Ideas.
-Deadline: 14th October, 2026. (Wednesday)
- some other relevant details

2)Meeting on selection of Ideas
Date: 14th October, 2026 (Wednesday)
Time: 5:20pm to 6:50pm
Duration: 1 hour and 30 minutes.

3) RESEARCH ON THOSE SELECTED TRACKS
-Deadline: 18th October, 2026 (Sunday)

4) DISCUSSION ON RESEARCH AND ALLOCATION OF RESPONSIBILITIES
Date: 18th October, 2026 (Sunday)
Time: 5:20pm to 6:50pm 
Duration: 1 hour and 30 minutes.

5) COMMENCEMENT OF PROJECT
Date: 19th October, 2026 (Monday)

[9:02 PM] **JOEL:** The time may be modified later.

[9:03 PM] __[System notification]__

---

## October 14, 2026

[6:45 AM] **Katim:** @ArRazaq. what time will we meet today?

[7:05 AM] **ArRazaq.:**
> _Katim: @ArRazaq. what time will we meet today?_
**Poll: Happy Wednesday Gang, please select you're preferred ⏰ *time* for our meeting 🐕‍🦺🍭**
- 10:00am 🕊️
- 5:00pm 🤖
- 8:00pm 🫪
- In between( 5:00 - 8:00) pm ☃️

[7:05 AM] **ArRazaq.:** @all

[8:32 AM] **ArRazaq.:**
> _ArRazaq.: [poll_creation]_
Please vote @all the opening would end around 7pm today

[11:08 AM] **ArRazaq.:**
> _ArRazaq.: [poll_creation]_
It's decided then 5:00 pm @all

[2:16 PM] **Katim:** Hi guys .
Is it just me that does not find any other track as interesting as the one we discussed earlier?

[2:27 PM] **JOEL:** That's because we discussed so much on those Ideas that we forgot there were other tracks left for us to research about. 
I love the other guy's Idea- The one that talks about simulation of port operations. It's really going to be very demanding but if done well, could be worthwhile.

[2:39 PM] **You:**
> _Katim: Hi guys .
Is it just me that does not find any other track as interesting as the one we discussed earlier?_
Well it is our field so it's natural

[2:39 PM] **You:**
> _JOEL: That's because we discussed so much on those Ideas that we forgot there were other tracks left for us to research about. 
I love the other guy's Idea- The one that talks about simulation of port operations. It's really going to be very demanding but if done well, could be worthwhile._
Yup

[2:41 PM] **Katim:** [Voice message]

[2:42 PM] **Katim:** [Voice message]

[3:37 PM] **You:**
> _Katim: Voice message_
[Sticker]

[4:27 PM] **ArRazaq.:**
> _Katim: Hi guys .
Is it just me that does not find any other track as interesting as the one we discussed earlier?_
I do actually

[4:31 PM] **Katim:**
> _ArRazaq.: I do actually_
Great 
We have 30 minutes to hear those ideas

[5:05 PM] **+234 806 158 8349:** Evening @all

[5:06 PM] **+234 806 158 8349:** My research on track 6

An intelligent fish-farm management system that helps farmers reduce the cost of producing market-ready fish by learning from feeding, growth, mortality, and water-quality records.

[5:06 PM] **JOEL:** Could we have a voice call?

[5:08 PM] **Katim:** Are we all ready?@all

[5:08 PM] **Katim:** https://call.whatsapp.com/video/hmIyehVpNBOyljUmUlGbTh

[5:09 PM] **+234 806 158 8349:** Sure

[5:15 PM] **ArRazaq.:**
> _Katim: Voice message_
Ships go to plants to dump toxic waste, because of the quantity and type of waste varies, they have to make arrangements first

[5:15 PM] **ArRazaq.:** Sorry I came late my phone turned off

[5:16 PM] **You:** I'll join in a bit

[5:31 PM] **You:** Omo my network is buggy

[5:33 PM] **ArRazaq.:** [Image]

[5:34 PM] **+234 806 158 8349:** Track 6

Our fish-farming system combines sensors, automation, software, and machine learning to help farmers manage the entire fish-production cycle more efficiently.

The system records feeding expenditure, monitors water conditions, tracks growth, records mortality, and raises alerts when something appears wrong. It can also control an automatic feeder and activate equipment such as an aerator when defined conditions require intervention.

The central idea: Give fish farmers a system that helps them understand their farm, respond to problems, and improve production decisions using evidence from their own operations.

[5:57 PM] **You:** Sorry guys I have to go pick up an order

[6:55 PM] **You:** Is the call still on?

[6:56 PM] **You:** [Sticker]

[6:59 PM] **ArRazaq.:**
> _You: Is the call still on?_
[Sticker]

[7:00 PM] **ArRazaq.:** @ZXCHAM Bro we have come to a conclusion, smart fish pond

[7:00 PM] **You:**
> _ArRazaq.: @ZXCHAM Bro we have come to a conclusion, smart fish pond_
[Sticker]

[7:01 PM] **ArRazaq.:** _This message was deleted_

[7:07 PM] **ArRazaq.:** Feedback I got:

1. Should be able to differentiate fish with infection or when an infection manifests.

2. Should probably have a auto feeding mechanism.

3. Should probably be able to identify nutrition gaps or if there's a deficiency in feeding.

4. Making it auto cover when rain is falling is a long shot 🥲.
 
5. Making it cost effective is compulsory.

Please research other key problems or gaps as noted.

[7:09 PM] **ArRazaq.:** [Image]

[7:09 PM] **ArRazaq.:** [Image]

[7:12 PM] **ArRazaq.:** We would be having our next meeting by God's Grace on Monday..

and it's more of a assignment of roles and immediately kick-starting working on the project than a meeting.

 (we need to finalize the name of the project ver 1 and our team's name) @all 

Let's build something great guys!💫

[7:16 PM] **ArRazaq.:** [Image] This is the goal/motto 🙂‍↔️

[8:33 PM] **You:**
> _ArRazaq.: Image: This is the goal/motto 🙂‍↔️_
[Sticker]

[8:33 PM] **You:**
> _ArRazaq.: We would be having our next meeting by God's Grace on Monday..

and it's more of a assignment of roles and immediately kick-starting working on the project than a meeting.

 (we need to finalize the name of the project ver 1 and our team's name) @all 

Let's build something great guys!💫_
Alright

---

## October 15, 2026

[8:04 AM] **ArRazaq.:** [Image]

[8:09 AM] **ArRazaq.:**
> _You: Sticker_
[Sticker]

[1:06 PM] **+234 806 158 8349:** Good afternoon @all

[1:07 PM] **Katim:**
> _+234 806 158 8349: Good afternoon @all_
Good afternoon sir

[1:09 PM] **+234 806 158 8349:** The Intelligent Fish Farming Ecosystem
(A smarter, more accessible, transparent, and profitable future for fish farming in Nigeria and Africa)

The Idea
The system is an intelligent fish-farming ecosystem designed to help people start fish farming, manage their farms, monitor fish health and growth, access professional advice, purchase supplies, find buyers, and understand their profitability; all through one connected platform.

The platform will combine three major components:

• A web application for farm management, financial tracking, monitoring, analytics, and personalised recommendations.

• Smart fish-farming hardware for monitoring pond conditions and automating selected farming activities.

• A fishery marketplace and professional network connecting farmers with suppliers, fish doctors, equipment vendors, technicians, delivery providers, buyers, and other industry participants.

The platform will serve beginners, experienced fish farmers, aquaculture professionals, feed suppliers, fingerling producers, equipment vendors, fish sellers, wholesalers, retailers, restaurants, and individuals interested in aquaculture.

For a beginner, the system should provide a guided path from choosing a suitable fish species and establishing a pond to feeding, monitoring growth, managing expenses, harvesting, and selling the fish.

For an experienced farmer, it should provide advanced tools for monitoring multiple ponds, automating operations, analysing production, controlling costs, and improving decision-making.

Beyond technology, it should help create economic opportunities by connecting people who need aquaculture services with people who can provide them.

The ultimate goal is to make fish farming more accessible, measurable, transparent, and economically sustainable across Nigeria and eventually other African countries.

The Problems We Want to Solve

Fish farming has significant potential in Nigeria, but many farmers face challenges that affect production, costs, and profitability.

Some of the major problems include:

• High fish-feed costs and feed wastage.
• Fish mortality associated with poor water quality, disease, and inadequate management.
• Difficulty determining appropriate feeding schedules and quantities.
• Limited access to affordable and reliable monitoring equipment.
• Poor records of feeding, growth, mortality, and production expenses.
• Difficulty finding trustworthy fingerling suppliers, feed vendors, and equipment sellers.
• Limited access to qualified aquaculture professionals.
• Difficulty identifying potential buyers before harvesting.
• Uncertainty about when fish will reach market size.
• Difficulty estimating the actual cost of producing each kilogram of fish.
• Limited access to practical guidance for beginners.
• Inconsistent pricing and insufficient transparency in some product and service transactions.
• Difficulty accessing reliable installation, maintenance, transportation, and other support services.
• Limited opportunities for some skilled people to reach customers and earn income from their aquaculture knowledge.

Many farmers handle these activities manually or use separate tools that do not communicate with one another.

Our system aims to connect these activities through one integrated platform.
Rather than simply recording information, the system should help farmers understand what is happening on their farms, identify potential problems, make informed decisions, and connect with the people and resources needed to address those problems.

How the System Will Work

It will have three interconnected components.

• The Web Application
The web application will serve as the central management platform.

Users will be able to:
• Create accounts and personalised profiles.
• Establish and manage digital records for their farms and ponds.
• Monitor water conditions and equipment.
• Record feeding, growth, mortality, and expenses.
• Receive alerts and recommendations.
• Consult aquaculture professionals.
• Purchase supplies and services.
• Advertise fish for sale and find potential buyers.
• Monitor transactions and deliveries.
• Calculate production costs and estimated profit or loss.
• Access educational resources and the aquaculture community.
• Different users will receive dashboards appropriate to their roles and permissions.

The Smart Fish-Farming Device

Affordable electronic devices and sensors will connect physical ponds to the digital platform.
Depending on the equipment installed, the system could monitor:

• Water temperature.
• Dissolved oxygen.
• pH.
• Water level.
• Equipment operating status.
• Feeding activity.
• It could also control selected equipment, such as automatic feeders and aerators, when appropriate safeguards are in place.

For example, an automatic feeder could dispense a scheduled quantity of feed and report the operation to the farmer's dashboard.
If a reliable sensor detects a potentially dangerous water condition, the platform could issue an alert and recommend an appropriate response.

The hardware should continue performing essential local functions when internet connectivity is lost, store records locally, and synchronise them when connectivity returns.

The Fishery Marketplace and Community

The marketplace will connect farmers with suppliers, specialists, technicians, buyers, and other service providers.

It will support the buying and selling of products and services while helping users compare prices, assess providers, track transactions, and resolve disputes.

The community will allow participants to exchange knowledge, learn from experienced farmers, ask questions, and discover business opportunities.

Together, these three components will connect physical farming activities, digital farm management, professional support, and commercial transactions.

The Complete Fish-Farming Cycle

It should support the farmer throughout the entire production process, from the first idea to selling the fish and analysing the results.

Stage 1: A User Joins the Platform

A user discovers it through an intenet search, social media, a recommendation, or another farmer.
During registration, the user selects their primary interest.
For example:
• I want to start fish farming.
• I already operate a fish farm.
• I want to sell fish or farming supplies.
• I am a fish doctor or aquaculture specialist.
• I want to buy fish.
• I install or maintain farming equipment.
• I provide delivery or logistics services.
• I want to learn about aquaculture.

Each user receives a suitable dashboard.
Beginners receive guidance on getting started, while experienced farmers can access farm-management tools and more advanced features.

Stage 2: The Farmer Creates a Farm Plan

Suppose a user wants to begin rearing catfish.
Our system asks questions about:
• Location.
• Available space.
• Starting budget.
• Water supply.
• Electricity availability.
• Farming experience.
• Intended production scale.
• Available equipment.
Target market.

Using these details, the system generates a proposed farm plan.
The plan could include:
• A suitable pond or tank configuration.
• Recommended stocking arrangements.
• Essential equipment.
• Estimated fingerling requirements.
• Estimated feed requirements.
• Expected operating expenses.
• A preliminary production schedule.
• Potential harvesting targets.
• Estimated financial requirements.
• The plan should be adjustable to the farmer's circumstances and budget.
Recommendations should be based on relevant aquaculture guidance and the user's actual conditions rather than assuming that every farmer needs the same setup.

Stage 3: The Farmer Purchases Supplies

Once the plan is ready, the farmer can purchase supplies through the syste.

A starter package might contain:
• Fingerlings from a verified supplier.
• A suitable pond or tank.
• Appropriate fish feed.
• Nets and basic accessories.
• Water-testing equipment.
• Optional sensors and automatic feeding equipment.
• Setup instructions.
• Access to professional support.
• The platform can help identify suppliers near the farmer and coordinate delivery.
Where needed, a technician or trained service provider can assist with installation.
• Live fish delivery must account for oxygen supply, temperature, stocking density, transport duration, and safe acclimatisation.
• Affordable, modular packages
• Starter packages should be modular rather than forcing every customer to purchase an expensive, complete system.

A beginner could start with essential equipment and manual farm records, then upgrade to sensors and automation as the farm grows.
Every package should clearly distinguish essential items from optional upgrades.

Stage 4: The Farm Is Set Up
Once the supplies arrive, the system guides the farmer through pond preparation, water checks, equipment installation, and appropriate stocking procedures.
Each pond receives a digital record.

For example:

- Farm: My Catfish Farm.
- Pond: Pond 01.
- Species: Catfish.
- Stocking date: Recorded.
- Initial fish population: Recorded.
- Smart device: Connected, if installed.
- Monitoring status: Active.
This structure allows farmers to manage multiple ponds independently, even when they have different stocking dates, feeding schedules, and environmental conditions.

Stage 5: The System Monitors the Production Cycle
After stocking, it helps the farmer track feeding, water conditions, fish growth, mortality, and operating costs.
Feeding management
Farmers can follow suitable feeding schedules or configure them with professional guidance.

An automatic feeder can dispense scheduled quantities where supported by the installed equipment.
The platform records feeding times and the estimated quantity dispensed.

It is important to distinguish between feed dispensed and feed actually consumed. A feeder's measurement alone cannot prove that the fish consumed all the food.

Water monitoring
Sensors monitor selected water parameters and display the readings on the dashboard.
The system can alert farmers when measurements fall outside configured limits.

Where suitable equipment is installed, the controller may operate an aerator or another approved device automatically.
However, critical automated actions must have safeguards, reliable sensors, and manual overrides. An unsafe automatic water change, for example, could harm fish if the incoming water has unsuitable conditions.
Growth tracking
Farmers periodically record fish weights or other growth measurements.

Our system uses the records to show growth trends and estimate when the fish might reach the desired market size.

Mortality tracking
Farmers record deaths and changes in fish population.
The platform identifies unusual mortality trends and prompts investigation.

It should not automatically diagnose a disease from mortality records alone. Water conditions, stocking density, handling, feed quality, and other factors may also contribute.

The daily dashboard
The farmer should be able to open the application and quickly see:

• Current water-quality readings.
• Feeding activity.
• Estimated feed dispensed.
• Recorded fish population.
• Recent mortality.
• Growth trends.
• Equipment status.
• Outstanding alerts.
• Total expenses.
• Estimated time to target market size.

The purpose is to make farm management easier and more informed without requiring the farmer to consult multiple disconnected systems.

Stage 6: the system Helps the Farmer Make Better Decisions
This is where the platform moves beyond basic record-keeping.
Using available records, it can identify trends and flag situations that deserve attention.

For example, if feed expenditure increases but sampled fish weights do not improve as expected, it could recommend investigating feeding practices, feed quality, water conditions, stocking density, and possible health issues.

If water conditions become dangerous, the system can issue an alert and recommend an appropriate response.
If growth differs significantly from expectations, the platform can update the estimated harvest window.
It can also calculate production costs and help farmers assess whether their current practices are financially sustainable.

AI should support these decisions using reliable data, validated aquaculture knowledge, and appropriately tested models. It should communicate uncertainty instead of presenting every prediction as a fact.

Stage 7: Access to Fish Doctors and Other Professionals

If a farmer encounters a problem, they can request assistance from a qualified aquaculture professional.

With the farmer's permission, the professional could review:
• Water-quality history.
• Feeding records.
• Growth measurements.
• Mortality trends.
• Photographs or videos.
• Previous treatments.
• Relevant environmental and management information.
All from the software.

This provides more context than an isolated description of the problem.

The farmer can arrange a consultation, receive professional recommendations, and maintain a treatment history.
The platform can also provide reminders for agreed follow-up actions.
This could make professional support more accessible to small farmers who cannot afford to employ a specialist permanently.
Health-related recommendations and treatments must remain within the competence and legal scope of qualified professionals.

Stage 8: Harvest Planning

As fish approach the intended market size, our system helps the farmer plan harvesting.

Using available growth measurements and population records, it estimates:

• The likely harvest window.
- The approximate quantity available.
- The estimated average weight.
- Potential production revenue.
- Relevant harvesting and transportation requirements.
Because these are estimates, the farmer should verify actual fish sizes and quantities before committing to a delivery date or sale quantity.

Stage 9: Sale or consumption

The farmer lists available fish on the marketplace.
Listings could include:
• Species.
• Available quantity.
• Average or estimated weight.
• Price.
• Location.
• Expected availability.
• Delivery options.
• Restaurants, wholesalers, retailers, processors, and individual buyers can search for suitable suppliers.

Farmers can also advertise expected harvests before the fish are ready, helping potential buyers plan their purchases.

The platform can support order management, transaction records, and delivery coordination.
This reduces the need for farmers to wait until harvesting before looking for customers.

Stage 10: Calculate Profit and Improve the Next Cycle
After the fish are harvested or sold, our system compares actual results with the original plan.
It tracks expenses such as:
• Fingerlings.
Feed.
• Electricity and water.
• Labour.
• Medication and professional consultations.
• Equipment.
• Transportation.
• Maintenance.
• Other operating costs.

The platform calculates recorded revenue, estimated or actual profit or loss, and the cost per kilogram of fish produced.

Farmers can compare production cycles to identify what worked, where money was lost, and what should change next time.

The complete cycle is:
Plan --- Purchase --- Set up --- Stock --- Feed and monitor --- Manage health and growth --- Harvest --- Sell --- Analyse results --- Improve the next cycle.

The Marketplace and Professional Network

The system should not only help people manage farms. It should also connect the people and businesses that make fish farming possible.
The marketplace could support:

- Products
- Fingerlings and juvenile fish.
- Mature fish.
- Fish feed.
- Ponds and tanks.
- Nets and accessories.
- Pumps and aerators.
- Sensors and automatic feeders.
- Other suitable farming equipment and approved aquaculture products.
- Professional services
- Fish-health consultations.
- Aquaculture advice.
- Pond construction.
- Tank installation.
- Plumbing and water-system installation.
- Sensor installation.
- Feeder, pump, and aerator maintenance.
- Farm management training.
- Fish transportation.
- Harvesting, processing, and packaging.
- Fish buyers
- Restaurants.
- Hotels.
- Retailers.
- Wholesalers.
- Fish processors.
- Market traders.
- Individual consumers.

Each provider could maintain a profile showing their services, location, prices, availability, and relevant qualifications or verification status.

Farmers could compare providers and make informed choices.

The marketplace should include appropriate verification, verified-transaction reviews, clear refund policies, complaint handling, and dispute-resolution procedures.

The objective is to build a network in which farmers can find trustworthy services and service providers can reach customers.

Transparency and Fair Pricing

Transparency should be a core principle of the system, not an additional feature introduced later.
Farmers should be able to understand what they are paying for, compare suitable alternatives, track their transactions, and identify questionable charges.

A. Reference prices

The system could publish typical price ranges for commonly purchased items, such as:
- Fish feed.
- Fingerlings.
- Pond materials.
- Pumps and aerators.
- Sensors and controllers.
- Installation services.
- Transportation.
- Professional consultations.

These reference prices would help farmers judge whether a quote is reasonable.
However, the platform should not assume that every seller must charge exactly the same price. 

Legitimate differences can result from product quality, location, packaging, availability, delivery costs, and service conditions.
Where possible, prices should be compared using equivalent specifications and units, such as price per kilogram of feed or price per fingerling.
Reference prices should be updated regularly and should indicate when the information was last reviewed.

B. Itemised pricing

Before a farmer confirms an order, the platform should display:
- Product or service description.
- Quantity and specifications.
- Unit price.
- Subtotal.
- Delivery charge.
- Installation charge, where applicable.
- Platform fees.
- Discounts.
- Final amount payable.
Optional upgrades should be clearly separated from essential items.
Farmers should not discover unexpected charges after making a purchase.

C. Transparent supplier comparisons

Farmers should be able to compare suppliers based on:
- Price.
- Product quality and specifications.
- Location.
- Availability.
- Delivery time.
- Verified customer reviews.
- Delivery performance.
- Relevant credentials.
The cheapest seller should not automatically be treated as the best seller. Product suitability, reliability, and delivery conditions matter too.
Paid promotions should be clearly labelled, and ranking systems should not secretly favour providers simply because they pay higher commissions.

D. Transparent transactions and delivery

Every transaction should have a unique record containing the relevant information, including:
- Buyer and seller.
- Products or services purchased.
- Agreed quantities and prices.
- Fees and discounts.
- Payment status.
- Dispatch information.
- Delivery status.
- Relevant confirmation or evidence.
- Complaints and dispute outcomes, where applicable.
This provides a clearer record if an order is delayed, a quantity is missing, or the delivered product differs from what was agreed.

Payments should be handled through appropriate payment providers, with suitable safeguards for refunds, disputes, and transaction security.

E. Trustworthy suppliers and professional services

It should introduce appropriate verification for suppliers and professionals.
The platform should make the distinction between verified and unverified providers clear.
Reviews should be tied to genuine transactions where possible, and users should be able to report misleading listings, suspicious behaviour, or poor service.

For medicines and fish-health products, the platform should provide accurate product information and comply with relevant regulations. Farmers should not be encouraged to choose treatments solely because they are cheaper.

F. Transparent farm finances

The farm dashboard should help users understand the actual cost of production.
Farmers should be able to see how much they have spent on feed, fingerlings, equipment, utilities, labour, health services, transportation, and other costs.

The platform can compare actual expenses with the original budget and calculate cost per kilogram of fish produced.
 
The system will combine smart fish-farm monitoring, AI-assisted management, and a transparent marketplace to help farmers reduce waste, track expenses, improve production, and connect with suppliers, professionals, and buyers.

It will create economic opportunities for fish farmers, technicians, suppliers, delivery providers, and aquaculture specialists while promoting fair pricing and accountability.

Development will begin with a basic web application, followed by smart hardware, real-world testing, marketplace integration, and advanced AI features.
The system will remain affordable, support offline operation, and prioritise reliable data, verified providers, and practical solutions.

The goal is to make fish farming more accessible, profitable, and transparent while creating sustainable business and employment opportunities across Nigeria and Africa.

[1:10 PM] **+234 806 158 8349:** Tried putting somethings together☝️

[1:13 PM] **You:**
> _+234 806 158 8349: Good afternoon @all_
Afternoon

[1:14 PM] **You:**
> _+234 806 158 8349: The Intelligent Fish Farming Ecosystem
(A smarter, more accessible, transparent, and profitable future for fish farming in Nigeria and Africa)

The Idea
The system is an intelligent fish-farming ecosystem designed to help people start fish farming, manage their farms, monitor fish health and growth, access professional advice, purchase supplies, find buyers, and understand their profitability; all through one connected platform.

The platform will combine three major components:

• A web application for farm management, financial tracking, monitoring, analytics, and personalised recommendations.

• Smart fish-farming hardware for monitoring pond conditions and automating selected farming activities.

• A fishery marketplace and professional network connecting farmers with suppliers, fish doctors, equipment vendors, technicians, delivery providers, buyers, and other industry participants.

The platform will serve beginners, experienced fish farmers, aquaculture professionals, feed suppliers, fingerling producers, equipment vendors, fish sellers, wholesalers, retailers, restaurants, and individuals interested in aquaculture.

For a beginner, the system should provide a guided path from choosing a suitable fish species and establishing a pond to feeding, monitoring growth, managing expenses, harvesting, and selling the fish.

For an experienced farmer, it should provide advanced tools for monitoring multiple ponds, automating operations, analysing production, controlling costs, and improving decision-making.

Beyond technology, it should help create economic opportunities by connecting people who need aquaculture services with people who can provide them.

The ultimate goal is to make fish farming more accessible, measurable, transparent, and economically sustainable across Nigeria and eventually other African countries.

The Problems We Want to Solve

Fish farming has significant potential in Nigeria, but many farmers face challenges that affect production, costs, and profitability.

Some of the major problems include:

• High fish-feed costs and feed wastage.
• Fish mortality associated with poor water quality, disease, and inadequate management.
• Difficulty determining appropriate feeding schedules and quantities.
• Limited access to affordable and reliable monitoring equipment.
• Poor records of feeding, growth, mortality, and production expenses.
• Difficulty finding trustworthy fingerling suppliers, feed vendors, and equipment sellers.
• Limited access to qualified aquaculture professionals.
• Difficulty identifying potential buyers before harvesting.
• Uncertainty about when fish will reach market size.
• Difficulty estimating the actual cost of producing each kilogram of fish.
• Limited access to practical guidance for beginners.
• Inconsistent pricing and insufficient transparency in some product and service transactions.
• Difficulty accessing reliable installation, maintenance, transportation, and other support services.
• Limited opportunities for some skilled people to reach customers and earn income from their aquaculture knowledge.

Many farmers handle these activities manually or use separate tools that do not communicate with one another.

Our system aims to connect these activities through one integrated platform.
Rather than simply recording information, the system should help farmers understand what is happening on their farms, identify potential problems, make informed decisions, and connect with the people and resources needed to address those problems.

How the System Will Work

It will have three interconnected components.

• The Web Application
The web application will serve as the central management platform.

Users will be able to:
• Create accounts and personalised profiles.
• Establish and manage digital records for their farms and ponds.
• Monitor water conditions and equipment.
• Record feeding, growth, mortality, and expenses.
• Receive alerts and recommendations.
• Consult aquaculture professionals.
• Purchase supplies and services.
• Advertise fish for sale and find potential buyers.
• Monitor transactions and deliveries.
• Calculate production costs and estimated profit or loss.
• Access educational resources and the aquaculture community.
• Different users will receive dashboards appropriate to their roles and permissions.

The Smart Fish-Farming Device

Affordable electronic devices and sensors will connect physical ponds to the digital platform.
Depending on the equipment installed, the system could monitor:

• Water temperature.
• Dissolved oxygen.
• pH.
• Water level.
• Equipment operating status.
• Feeding activity.
• It could also control selected equipment, such as automatic feeders and aerators, when appropriate safeguards are in place.

For example, an automatic feeder could dispense a scheduled quantity of feed and report the operation to the farmer's dashboard.
If a reliable sensor detects a potentially dangerous water condition, the platform could issue an alert and recommend an appropriate response.

The hardware should continue performing essential local functions when internet connectivity is lost, store records locally, and synchronise them when connectivity returns.

The Fishery Marketplace and Community

The marketplace will connect farmers with suppliers, specialists, technicians, buyers, and other service providers.

It will support the buying and selling of products and services while helping users compare prices, assess providers, track transactions, and resolve disputes.

The community will allow participants to exchange knowledge, learn from experienced farmers, ask questions, and discover business opportunities.

Together, these three components will connect physical farming activities, digital farm management, professional support, and commercial transactions.

The Complete Fish-Farming Cycle

It should support the farmer throughout the entire production process, from the first idea to selling the fish and analysing the results.

Stage 1: A User Joins the Platform

A user discovers it through an intenet search, social media, a recommendation, or another farmer.
During registration, the user selects their primary interest.
For example:
• I want to start fish farming.
• I already operate a fish farm.
• I want to sell fish or farming supplies.
• I am a fish doctor or aquaculture specialist.
• I want to buy fish.
• I install or maintain farming equipment.
• I provide delivery or logistics services.
• I want to learn about aquaculture.

Each user receives a suitable dashboard.
Beginners receive guidance on getting started, while experienced farmers can access farm-management tools and more advanced features.

Stage 2: The Farmer Creates a Farm Plan

Suppose a user wants to begin rearing catfish.
Our system asks questions about:
• Location.
• Available space.
• Starting budget.
• Water supply.
• Electricity availability.
• Farming experience.
• Intended production scale.
• Available equipment.
Target market.

Using these details, the system generates a proposed farm plan.
The plan could include:
• A suitable pond or tank configuration.
• Recommended stocking arrangements.
• Essential equipment.
• Estimated fingerling requirements.
• Estimated feed requirements.
• Expected operating expenses.
• A preliminary production schedule.
• Potential harvesting targets.
• Estimated financial requirements.
• The plan should be adjustable to the farmer's circumstances and budget.
Recommendations should be based on relevant aquaculture guidance and the user's actual conditions rather than assuming that every farmer needs the same setup.

Stage 3: The Farmer Purchases Supplies

Once the plan is ready, the farmer can purchase supplies through the syste.

A starter package might contain:
• Fingerlings from a verified supplier.
• A suitable pond or tank.
• Appropriate fish feed.
• Nets and basic accessories.
• Water-testing equipment.
• Optional sensors and automatic feeding equipment.
• Setup instructions.
• Access to professional support.
• The platform can help identify suppliers near the farmer and coordinate delivery.
Where needed, a technician or trained service provider can assist with installation.
• Live fish delivery must account for oxygen supply, temperature, stocking density, transport duration, and safe acclimatisation.
• Affordable, modular packages
• Starter packages should be modular rather than forcing every customer to purchase an expensive, complete system.

A beginner could start with essential equipment and manual farm records, then upgrade to sensors and automation as the farm grows.
Every package should clearly distinguish essential items from optional upgrades.

Stage 4: The Farm Is Set Up
Once the supplies arrive, the system guides the farmer through pond preparation, water checks, equipment installation, and appropriate stocking procedures.
Each pond receives a digital record.

For example:

- Farm: My Catfish Farm.
- Pond: Pond 01.
- Species: Catfish.
- Stocking date: Recorded.
- Initial fish population: Recorded.
- Smart device: Connected, if installed.
- Monitoring status: Active.
This structure allows farmers to manage multiple ponds independently, even when they have different stocking dates, feeding schedules, and environmental conditions.

Stage 5: The System Monitors the Production Cycle
After stocking, it helps the farmer track feeding, water conditions, fish growth, mortality, and operating costs.
Feeding management
Farmers can follow suitable feeding schedules or configure them with professional guidance.

An automatic feeder can dispense scheduled quantities where supported by the installed equipment.
The platform records feeding times and the estimated quantity dispensed.

It is important to distinguish between feed dispensed and feed actually consumed. A feeder's measurement alone cannot prove that the fish consumed all the food.

Water monitoring
Sensors monitor selected water parameters and display the readings on the dashboard.
The system can alert farmers when measurements fall outside configured limits.

Where suitable equipment is installed, the controller may operate an aerator or another approved device automatically.
However, critical automated actions must have safeguards, reliable sensors, and manual overrides. An unsafe automatic water change, for example, could harm fish if the incoming water has unsuitable conditions.
Growth tracking
Farmers periodically record fish weights or other growth measurements.

Our system uses the records to show growth trends and estimate when the fish might reach the desired market size.

Mortality tracking
Farmers record deaths and changes in fish population.
The platform identifies unusual mortality trends and prompts investigation.

It should not automatically diagnose a disease from mortality records alone. Water conditions, stocking density, handling, feed quality, and other factors may also contribute.

The daily dashboard
The farmer should be able to open the application and quickly see:

• Current water-quality readings.
• Feeding activity.
• Estimated feed dispensed.
• Recorded fish population.
• Recent mortality.
• Growth trends.
• Equipment status.
• Outstanding alerts.
• Total expenses.
• Estimated time to target market size.

The purpose is to make farm management easier and more informed without requiring the farmer to consult multiple disconnected systems.

Stage 6: the system Helps the Farmer Make Better Decisions
This is where the platform moves beyond basic record-keeping.
Using available records, it can identify trends and flag situations that deserve attention.

For example, if feed expenditure increases but sampled fish weights do not improve as expected, it could recommend investigating feeding practices, feed quality, water conditions, stocking density, and possible health issues.

If water conditions become dangerous, the system can issue an alert and recommend an appropriate response.
If growth differs significantly from expectations, the platform can update the estimated harvest window.
It can also calculate production costs and help farmers assess whether their current practices are financially sustainable.

AI should support these decisions using reliable data, validated aquaculture knowledge, and appropriately tested models. It should communicate uncertainty instead of presenting every prediction as a fact.

Stage 7: Access to Fish Doctors and Other Professionals

If a farmer encounters a problem, they can request assistance from a qualified aquaculture professional.

With the farmer's permission, the professional could review:
• Water-quality history.
• Feeding records.
• Growth measurements.
• Mortality trends.
• Photographs or videos.
• Previous treatments.
• Relevant environmental and management information.
All from the software.

This provides more context than an isolated description of the problem.

The farmer can arrange a consultation, receive professional recommendations, and maintain a treatment history.
The platform can also provide reminders for agreed follow-up actions.
This could make professional support more accessible to small farmers who cannot afford to employ a specialist permanently.
Health-related recommendations and treatments must remain within the competence and legal scope of qualified professionals.

Stage 8: Harvest Planning

As fish approach the intended market size, our system helps the farmer plan harvesting.

Using available growth measurements and population records, it estimates:

• The likely harvest window.
- The approximate quantity available.
- The estimated average weight.
- Potential production revenue.
- Relevant harvesting and transportation requirements.
Because these are estimates, the farmer should verify actual fish sizes and quantities before committing to a delivery date or sale quantity.

Stage 9: Sale or consumption

The farmer lists available fish on the marketplace.
Listings could include:
• Species.
• Available quantity.
• Average or estimated weight.
• Price.
• Location.
• Expected availability.
• Delivery options.
• Restaurants, wholesalers, retailers, processors, and individual buyers can search for suitable suppliers.

Farmers can also advertise expected harvests before the fish are ready, helping potential buyers plan their purchases.

The platform can support order management, transaction records, and delivery coordination.
This reduces the need for farmers to wait until harvesting before looking for customers.

Stage 10: Calculate Profit and Improve the Next Cycle
After the fish are harvested or sold, our system compares actual results with the original plan.
It tracks expenses such as:
• Fingerlings.
Feed.
• Electricity and water.
• Labour.
• Medication and professional consultations.
• Equipment.
• Transportation.
• Maintenance.
• Other operating costs.

The platform calculates recorded revenue, estimated or actual profit or loss, and the cost per kilogram of fish produced.

Farmers can compare production cycles to identify what worked, where money was lost, and what should change next time.

The complete cycle is:
Plan --- Purchase --- Set up --- Stock --- Feed and monitor --- Manage health and growth --- Harvest --- Sell --- Analyse results --- Improve the next cycle.

The Marketplace and Professional Network

The system should not only help people manage farms. It should also connect the people and businesses that make fish farming possible.
The marketplace could support:

- Products
- Fingerlings and juvenile fish.
- Mature fish.
- Fish feed.
- Ponds and tanks.
- Nets and accessories.
- Pumps and aerators.
- Sensors and automatic feeders.
- Other suitable farming equipment and approved aquaculture products.
- Professional services
- Fish-health consultations.
- Aquaculture advice.
- Pond construction.
- Tank installation.
- Plumbing and water-system installation.
- Sensor installation.
- Feeder, pump, and aerator maintenance.
- Farm management training.
- Fish transportation.
- Harvesting, processing, and packaging.
- Fish buyers
- Restaurants.
- Hotels.
- Retailers.
- Wholesalers.
- Fish processors.
- Market traders.
- Individual consumers.

Each provider could maintain a profile showing their services, location, prices, availability, and relevant qualifications or verification status.

Farmers could compare providers and make informed choices.

The marketplace should include appropriate verification, verified-transaction reviews, clear refund policies, complaint handling, and dispute-resolution procedures.

The objective is to build a network in which farmers can find trustworthy services and service providers can reach customers.

Transparency and Fair Pricing

Transparency should be a core principle of the system, not an additional feature introduced later.
Farmers should be able to understand what they are paying for, compare suitable alternatives, track their transactions, and identify questionable charges.

A. Reference prices

The system could publish typical price ranges for commonly purchased items, such as:
- Fish feed.
- Fingerlings.
- Pond materials.
- Pumps and aerators.
- Sensors and controllers.
- Installation services.
- Transportation.
- Professional consultations.

These reference prices would help farmers judge whether a quote is reasonable.
However, the platform should not assume that every seller must charge exactly the same price. 

Legitimate differences can result from product quality, location, packaging, availability, delivery costs, and service conditions.
Where possible, prices should be compared using equivalent specifications and units, such as price per kilogram of feed or price per fingerling.
Reference prices should be updated regularly and should indicate when the information was last reviewed.

B. Itemised pricing

Before a farmer confirms an order, the platform should display:
- Product or service description.
- Quantity and specifications.
- Unit price.
- Subtotal.
- Delivery charge.
- Installation charge, where applicable.
- Platform fees.
- Discounts.
- Final amount payable.
Optional upgrades should be clearly separated from essential items.
Farmers should not discover unexpected charges after making a purchase.

C. Transparent supplier comparisons

Farmers should be able to compare suppliers based on:
- Price.
- Product quality and specifications.
- Location.
- Availability.
- Delivery time.
- Verified customer reviews.
- Delivery performance.
- Relevant credentials.
The cheapest seller should not automatically be treated as the best seller. Product suitability, reliability, and delivery conditions matter too.
Paid promotions should be clearly labelled, and ranking systems should not secretly favour providers simply because they pay higher commissions.

D. Transparent transactions and delivery

Every transaction should have a unique record containing the relevant information, including:
- Buyer and seller.
- Products or services purchased.
- Agreed quantities and prices.
- Fees and discounts.
- Payment status.
- Dispatch information.
- Delivery status.
- Relevant confirmation or evidence.
- Complaints and dispute outcomes, where applicable.
This provides a clearer record if an order is delayed, a quantity is missing, or the delivered product differs from what was agreed.

Payments should be handled through appropriate payment providers, with suitable safeguards for refunds, disputes, and transaction security.

E. Trustworthy suppliers and professional services

It should introduce appropriate verification for suppliers and professionals.
The platform should make the distinction between verified and unverified providers clear.
Reviews should be tied to genuine transactions where possible, and users should be able to report misleading listings, suspicious behaviour, or poor service.

For medicines and fish-health products, the platform should provide accurate product information and comply with relevant regulations. Farmers should not be encouraged to choose treatments solely because they are cheaper.

F. Transparent farm finances

The farm dashboard should help users understand the actual cost of production.
Farmers should be able to see how much they have spent on feed, fingerlings, equipment, utilities, labour, health services, transportation, and other costs.

The platform can compare actual expenses with the original budget and calculate cost per kilogram of fish produced.
 
The system will combine smart fish-farm monitoring, AI-assisted management, and a transparent marketplace to help farmers reduce waste, track expenses, improve production, and connect with suppliers, professionals, and buyers.

It will create economic opportunities for fish farmers, technicians, suppliers, delivery providers, and aquaculture specialists while promoting fair pricing and accountability.

Development will begin with a basic web application, followed by smart hardware, real-world testing, marketplace integration, and advanced AI features.
The system will remain affordable, support offline operation, and prioritise reliable data, verified providers, and practical solutions.

The goal is to make fish farming more accessible, profitable, and transparent while creating sustainable business and employment opportunities across Nigeria and Africa._
I like the addition marketplace idea

[1:14 PM] **You:** [Sticker]

[4:39 PM] **ArRazaq.:**
> _+234 806 158 8349: The Intelligent Fish Farming Ecosystem
(A smarter, more accessible, transparent, and profitable future for fish farming in Nigeria and Africa)

The Idea
The system is an intelligent fish-farming ecosystem designed to help people start fish farming, manage their farms, monitor fish health and growth, access professional advice, purchase supplies, find buyers, and understand their profitability; all through one connected platform.

The platform will combine three major components:

• A web application for farm management, financial tracking, monitoring, analytics, and personalised recommendations.

• Smart fish-farming hardware for monitoring pond conditions and automating selected farming activities.

• A fishery marketplace and professional network connecting farmers with suppliers, fish doctors, equipment vendors, technicians, delivery providers, buyers, and other industry participants.

The platform will serve beginners, experienced fish farmers, aquaculture professionals, feed suppliers, fingerling producers, equipment vendors, fish sellers, wholesalers, retailers, restaurants, and individuals interested in aquaculture.

For a beginner, the system should provide a guided path from choosing a suitable fish species and establishing a pond to feeding, monitoring growth, managing expenses, harvesting, and selling the fish.

For an experienced farmer, it should provide advanced tools for monitoring multiple ponds, automating operations, analysing production, controlling costs, and improving decision-making.

Beyond technology, it should help create economic opportunities by connecting people who need aquaculture services with people who can provide them.

The ultimate goal is to make fish farming more accessible, measurable, transparent, and economically sustainable across Nigeria and eventually other African countries.

The Problems We Want to Solve

Fish farming has significant potential in Nigeria, but many farmers face challenges that affect production, costs, and profitability.

Some of the major problems include:

• High fish-feed costs and feed wastage.
• Fish mortality associated with poor water quality, disease, and inadequate management.
• Difficulty determining appropriate feeding schedules and quantities.
• Limited access to affordable and reliable monitoring equipment.
• Poor records of feeding, growth, mortality, and production expenses.
• Difficulty finding trustworthy fingerling suppliers, feed vendors, and equipment sellers.
• Limited access to qualified aquaculture professionals.
• Difficulty identifying potential buyers before harvesting.
• Uncertainty about when fish will reach market size.
• Difficulty estimating the actual cost of producing each kilogram of fish.
• Limited access to practical guidance for beginners.
• Inconsistent pricing and insufficient transparency in some product and service transactions.
• Difficulty accessing reliable installation, maintenance, transportation, and other support services.
• Limited opportunities for some skilled people to reach customers and earn income from their aquaculture knowledge.

Many farmers handle these activities manually or use separate tools that do not communicate with one another.

Our system aims to connect these activities through one integrated platform.
Rather than simply recording information, the system should help farmers understand what is happening on their farms, identify potential problems, make informed decisions, and connect with the people and resources needed to address those problems.

How the System Will Work

It will have three interconnected components.

• The Web Application
The web application will serve as the central management platform.

Users will be able to:
• Create accounts and personalised profiles.
• Establish and manage digital records for their farms and ponds.
• Monitor water conditions and equipment.
• Record feeding, growth, mortality, and expenses.
• Receive alerts and recommendations.
• Consult aquaculture professionals.
• Purchase supplies and services.
• Advertise fish for sale and find potential buyers.
• Monitor transactions and deliveries.
• Calculate production costs and estimated profit or loss.
• Access educational resources and the aquaculture community.
• Different users will receive dashboards appropriate to their roles and permissions.

The Smart Fish-Farming Device

Affordable electronic devices and sensors will connect physical ponds to the digital platform.
Depending on the equipment installed, the system could monitor:

• Water temperature.
• Dissolved oxygen.
• pH.
• Water level.
• Equipment operating status.
• Feeding activity.
• It could also control selected equipment, such as automatic feeders and aerators, when appropriate safeguards are in place.

For example, an automatic feeder could dispense a scheduled quantity of feed and report the operation to the farmer's dashboard.
If a reliable sensor detects a potentially dangerous water condition, the platform could issue an alert and recommend an appropriate response.

The hardware should continue performing essential local functions when internet connectivity is lost, store records locally, and synchronise them when connectivity returns.

The Fishery Marketplace and Community

The marketplace will connect farmers with suppliers, specialists, technicians, buyers, and other service providers.

It will support the buying and selling of products and services while helping users compare prices, assess providers, track transactions, and resolve disputes.

The community will allow participants to exchange knowledge, learn from experienced farmers, ask questions, and discover business opportunities.

Together, these three components will connect physical farming activities, digital farm management, professional support, and commercial transactions.

The Complete Fish-Farming Cycle

It should support the farmer throughout the entire production process, from the first idea to selling the fish and analysing the results.

Stage 1: A User Joins the Platform

A user discovers it through an intenet search, social media, a recommendation, or another farmer.
During registration, the user selects their primary interest.
For example:
• I want to start fish farming.
• I already operate a fish farm.
• I want to sell fish or farming supplies.
• I am a fish doctor or aquaculture specialist.
• I want to buy fish.
• I install or maintain farming equipment.
• I provide delivery or logistics services.
• I want to learn about aquaculture.

Each user receives a suitable dashboard.
Beginners receive guidance on getting started, while experienced farmers can access farm-management tools and more advanced features.

Stage 2: The Farmer Creates a Farm Plan

Suppose a user wants to begin rearing catfish.
Our system asks questions about:
• Location.
• Available space.
• Starting budget.
• Water supply.
• Electricity availability.
• Farming experience.
• Intended production scale.
• Available equipment.
Target market.

Using these details, the system generates a proposed farm plan.
The plan could include:
• A suitable pond or tank configuration.
• Recommended stocking arrangements.
• Essential equipment.
• Estimated fingerling requirements.
• Estimated feed requirements.
• Expected operating expenses.
• A preliminary production schedule.
• Potential harvesting targets.
• Estimated financial requirements.
• The plan should be adjustable to the farmer's circumstances and budget.
Recommendations should be based on relevant aquaculture guidance and the user's actual conditions rather than assuming that every farmer needs the same setup.

Stage 3: The Farmer Purchases Supplies

Once the plan is ready, the farmer can purchase supplies through the syste.

A starter package might contain:
• Fingerlings from a verified supplier.
• A suitable pond or tank.
• Appropriate fish feed.
• Nets and basic accessories.
• Water-testing equipment.
• Optional sensors and automatic feeding equipment.
• Setup instructions.
• Access to professional support.
• The platform can help identify suppliers near the farmer and coordinate delivery.
Where needed, a technician or trained service provider can assist with installation.
• Live fish delivery must account for oxygen supply, temperature, stocking density, transport duration, and safe acclimatisation.
• Affordable, modular packages
• Starter packages should be modular rather than forcing every customer to purchase an expensive, complete system.

A beginner could start with essential equipment and manual farm records, then upgrade to sensors and automation as the farm grows.
Every package should clearly distinguish essential items from optional upgrades.

Stage 4: The Farm Is Set Up
Once the supplies arrive, the system guides the farmer through pond preparation, water checks, equipment installation, and appropriate stocking procedures.
Each pond receives a digital record.

For example:

- Farm: My Catfish Farm.
- Pond: Pond 01.
- Species: Catfish.
- Stocking date: Recorded.
- Initial fish population: Recorded.
- Smart device: Connected, if installed.
- Monitoring status: Active.
This structure allows farmers to manage multiple ponds independently, even when they have different stocking dates, feeding schedules, and environmental conditions.

Stage 5: The System Monitors the Production Cycle
After stocking, it helps the farmer track feeding, water conditions, fish growth, mortality, and operating costs.
Feeding management
Farmers can follow suitable feeding schedules or configure them with professional guidance.

An automatic feeder can dispense scheduled quantities where supported by the installed equipment.
The platform records feeding times and the estimated quantity dispensed.

It is important to distinguish between feed dispensed and feed actually consumed. A feeder's measurement alone cannot prove that the fish consumed all the food.

Water monitoring
Sensors monitor selected water parameters and display the readings on the dashboard.
The system can alert farmers when measurements fall outside configured limits.

Where suitable equipment is installed, the controller may operate an aerator or another approved device automatically.
However, critical automated actions must have safeguards, reliable sensors, and manual overrides. An unsafe automatic water change, for example, could harm fish if the incoming water has unsuitable conditions.
Growth tracking
Farmers periodically record fish weights or other growth measurements.

Our system uses the records to show growth trends and estimate when the fish might reach the desired market size.

Mortality tracking
Farmers record deaths and changes in fish population.
The platform identifies unusual mortality trends and prompts investigation.

It should not automatically diagnose a disease from mortality records alone. Water conditions, stocking density, handling, feed quality, and other factors may also contribute.

The daily dashboard
The farmer should be able to open the application and quickly see:

• Current water-quality readings.
• Feeding activity.
• Estimated feed dispensed.
• Recorded fish population.
• Recent mortality.
• Growth trends.
• Equipment status.
• Outstanding alerts.
• Total expenses.
• Estimated time to target market size.

The purpose is to make farm management easier and more informed without requiring the farmer to consult multiple disconnected systems.

Stage 6: the system Helps the Farmer Make Better Decisions
This is where the platform moves beyond basic record-keeping.
Using available records, it can identify trends and flag situations that deserve attention.

For example, if feed expenditure increases but sampled fish weights do not improve as expected, it could recommend investigating feeding practices, feed quality, water conditions, stocking density, and possible health issues.

If water conditions become dangerous, the system can issue an alert and recommend an appropriate response.
If growth differs significantly from expectations, the platform can update the estimated harvest window.
It can also calculate production costs and help farmers assess whether their current practices are financially sustainable.

AI should support these decisions using reliable data, validated aquaculture knowledge, and appropriately tested models. It should communicate uncertainty instead of presenting every prediction as a fact.

Stage 7: Access to Fish Doctors and Other Professionals

If a farmer encounters a problem, they can request assistance from a qualified aquaculture professional.

With the farmer's permission, the professional could review:
• Water-quality history.
• Feeding records.
• Growth measurements.
• Mortality trends.
• Photographs or videos.
• Previous treatments.
• Relevant environmental and management information.
All from the software.

This provides more context than an isolated description of the problem.

The farmer can arrange a consultation, receive professional recommendations, and maintain a treatment history.
The platform can also provide reminders for agreed follow-up actions.
This could make professional support more accessible to small farmers who cannot afford to employ a specialist permanently.
Health-related recommendations and treatments must remain within the competence and legal scope of qualified professionals.

Stage 8: Harvest Planning

As fish approach the intended market size, our system helps the farmer plan harvesting.

Using available growth measurements and population records, it estimates:

• The likely harvest window.
- The approximate quantity available.
- The estimated average weight.
- Potential production revenue.
- Relevant harvesting and transportation requirements.
Because these are estimates, the farmer should verify actual fish sizes and quantities before committing to a delivery date or sale quantity.

Stage 9: Sale or consumption

The farmer lists available fish on the marketplace.
Listings could include:
• Species.
• Available quantity.
• Average or estimated weight.
• Price.
• Location.
• Expected availability.
• Delivery options.
• Restaurants, wholesalers, retailers, processors, and individual buyers can search for suitable suppliers.

Farmers can also advertise expected harvests before the fish are ready, helping potential buyers plan their purchases.

The platform can support order management, transaction records, and delivery coordination.
This reduces the need for farmers to wait until harvesting before looking for customers.

Stage 10: Calculate Profit and Improve the Next Cycle
After the fish are harvested or sold, our system compares actual results with the original plan.
It tracks expenses such as:
• Fingerlings.
Feed.
• Electricity and water.
• Labour.
• Medication and professional consultations.
• Equipment.
• Transportation.
• Maintenance.
• Other operating costs.

The platform calculates recorded revenue, estimated or actual profit or loss, and the cost per kilogram of fish produced.

Farmers can compare production cycles to identify what worked, where money was lost, and what should change next time.

The complete cycle is:
Plan --- Purchase --- Set up --- Stock --- Feed and monitor --- Manage health and growth --- Harvest --- Sell --- Analyse results --- Improve the next cycle.

The Marketplace and Professional Network

The system should not only help people manage farms. It should also connect the people and businesses that make fish farming possible.
The marketplace could support:

- Products
- Fingerlings and juvenile fish.
- Mature fish.
- Fish feed.
- Ponds and tanks.
- Nets and accessories.
- Pumps and aerators.
- Sensors and automatic feeders.
- Other suitable farming equipment and approved aquaculture products.
- Professional services
- Fish-health consultations.
- Aquaculture advice.
- Pond construction.
- Tank installation.
- Plumbing and water-system installation.
- Sensor installation.
- Feeder, pump, and aerator maintenance.
- Farm management training.
- Fish transportation.
- Harvesting, processing, and packaging.
- Fish buyers
- Restaurants.
- Hotels.
- Retailers.
- Wholesalers.
- Fish processors.
- Market traders.
- Individual consumers.

Each provider could maintain a profile showing their services, location, prices, availability, and relevant qualifications or verification status.

Farmers could compare providers and make informed choices.

The marketplace should include appropriate verification, verified-transaction reviews, clear refund policies, complaint handling, and dispute-resolution procedures.

The objective is to build a network in which farmers can find trustworthy services and service providers can reach customers.

Transparency and Fair Pricing

Transparency should be a core principle of the system, not an additional feature introduced later.
Farmers should be able to understand what they are paying for, compare suitable alternatives, track their transactions, and identify questionable charges.

A. Reference prices

The system could publish typical price ranges for commonly purchased items, such as:
- Fish feed.
- Fingerlings.
- Pond materials.
- Pumps and aerators.
- Sensors and controllers.
- Installation services.
- Transportation.
- Professional consultations.

These reference prices would help farmers judge whether a quote is reasonable.
However, the platform should not assume that every seller must charge exactly the same price. 

Legitimate differences can result from product quality, location, packaging, availability, delivery costs, and service conditions.
Where possible, prices should be compared using equivalent specifications and units, such as price per kilogram of feed or price per fingerling.
Reference prices should be updated regularly and should indicate when the information was last reviewed.

B. Itemised pricing

Before a farmer confirms an order, the platform should display:
- Product or service description.
- Quantity and specifications.
- Unit price.
- Subtotal.
- Delivery charge.
- Installation charge, where applicable.
- Platform fees.
- Discounts.
- Final amount payable.
Optional upgrades should be clearly separated from essential items.
Farmers should not discover unexpected charges after making a purchase.

C. Transparent supplier comparisons

Farmers should be able to compare suppliers based on:
- Price.
- Product quality and specifications.
- Location.
- Availability.
- Delivery time.
- Verified customer reviews.
- Delivery performance.
- Relevant credentials.
The cheapest seller should not automatically be treated as the best seller. Product suitability, reliability, and delivery conditions matter too.
Paid promotions should be clearly labelled, and ranking systems should not secretly favour providers simply because they pay higher commissions.

D. Transparent transactions and delivery

Every transaction should have a unique record containing the relevant information, including:
- Buyer and seller.
- Products or services purchased.
- Agreed quantities and prices.
- Fees and discounts.
- Payment status.
- Dispatch information.
- Delivery status.
- Relevant confirmation or evidence.
- Complaints and dispute outcomes, where applicable.
This provides a clearer record if an order is delayed, a quantity is missing, or the delivered product differs from what was agreed.

Payments should be handled through appropriate payment providers, with suitable safeguards for refunds, disputes, and transaction security.

E. Trustworthy suppliers and professional services

It should introduce appropriate verification for suppliers and professionals.
The platform should make the distinction between verified and unverified providers clear.
Reviews should be tied to genuine transactions where possible, and users should be able to report misleading listings, suspicious behaviour, or poor service.

For medicines and fish-health products, the platform should provide accurate product information and comply with relevant regulations. Farmers should not be encouraged to choose treatments solely because they are cheaper.

F. Transparent farm finances

The farm dashboard should help users understand the actual cost of production.
Farmers should be able to see how much they have spent on feed, fingerlings, equipment, utilities, labour, health services, transportation, and other costs.

The platform can compare actual expenses with the original budget and calculate cost per kilogram of fish produced.
 
The system will combine smart fish-farm monitoring, AI-assisted management, and a transparent marketplace to help farmers reduce waste, track expenses, improve production, and connect with suppliers, professionals, and buyers.

It will create economic opportunities for fish farmers, technicians, suppliers, delivery providers, and aquaculture specialists while promoting fair pricing and accountability.

Development will begin with a basic web application, followed by smart hardware, real-world testing, marketplace integration, and advanced AI features.
The system will remain affordable, support offline operation, and prioritise reliable data, verified providers, and practical solutions.

The goal is to make fish farming more accessible, profitable, and transparent while creating sustainable business and employment opportunities across Nigeria and Africa._
Love this

[4:47 PM] **ArRazaq.:** So we have 4 phases 

Phase 1

• What kind of hardware and programming frameworks/languages do we need to use.

Phase 2

• Assembling the circuit and demonstrating it via simulator.

Phase 3

• Building the Software with placeholder databases and avoid over complicating it till we get grant.

Phase 4

• After proceeding to the 12 week accelerator we finish the software making it ready as a product as well as acquiring cheap water resistant components to actualize the hardware.

[5:19 PM] **ArRazaq.:** [Forwarded] [Sticker]

[5:39 PM] **You:**
> _ArRazaq.: So we have 4 phases 

Phase 1

• What kind of hardware and programming frameworks/languages do we need to use.

Phase 2

• Assembling the circuit and demonstrating it via simulator.

Phase 3

• Building the Software with placeholder databases and avoid over complicating it till we get grant.

Phase 4

• After proceeding to the 12 week accelerator we finish the software making it ready as a product as well as acquiring cheap water resistant components to actualize the hardware._
We all know we're running on Python🐍⚡

[5:40 PM] **You:**
> _ArRazaq.: So we have 4 phases 

Phase 1

• What kind of hardware and programming frameworks/languages do we need to use.

Phase 2

• Assembling the circuit and demonstrating it via simulator.

Phase 3

• Building the Software with placeholder databases and avoid over complicating it till we get grant.

Phase 4

• After proceeding to the 12 week accelerator we finish the software making it ready as a product as well as acquiring cheap water resistant components to actualize the hardware._
Oh and Arduino

[5:45 PM] **ArRazaq.:**
> _You: Oh and Arduino_
But esp got wifi I guess we can use that for scale

[5:45 PM] **You:**
> _ArRazaq.: But esp got wifi I guess we can use that for scale_
[Sticker]

[9:47 PM] **ArRazaq.:** > Copied live from the NIMASA BEAP website 

How maturity (TRL) is scored
Judges validate your self-assessed Technology Readiness Level against evidence. 

Only the validated TRL counts, capped at TRL 6. If your solution has several critical components, the lowest one sets your TRL.

Claiming 2+ levels above the validated TRL costs 2 feasibility points; TRL 7+ claims are flagged for evidence review.

TRL band to score conversion
Validated TRL	Band score	Evidence judges must see

TRL 1–2 · Concept	3/10	Written concept, research summary, or design document

TRL 3 · Proof of concept	5/10	Analytical/experimental proof; working simulation or partial prototype

TRL 4 · Lab-validated	7/10	Functional prototype demonstrated live; basic test results

TRL 5 · Relevant environment	9/10	Prototype tested in field-like conditions; early pilot users or data

TRL 6 (cap) · Demonstrated (capped)	10/10	Pilot-scale demonstration with measured results
Scoring Process

Each submission is scored by at least 3 independent panellists, who each validate your TRL

Variances greater than 1 TRL level or 10 rubric points are resolved in a calibration session and logged
Final scores are the weighted total across all criteria (out of 100)
The Steering Committee ratifies the final results

[9:47 PM] **ArRazaq.:** After we finish making the prototype we would be at TRL3 which is not bad 🙂‍↔️

---

## October 17, 2026

[6:10 AM] **Katim:** https://youtu.be/7suci93lW84?si=MOlWERzb_9ESvSBm

[12:05 PM] **ArRazaq.:**
> _Katim: https://youtu.be/7suci93lW84?si=MOlWERzb_9ESvSBm_
[Sticker]

[7:27 PM] **JOEL:** My greetings to you all.
How is your research going?

[7:35 PM] **You:**
> _JOEL: My greetings to you all.
How is your research going?_
[Sticker]

[11:10 PM] **Katim:**
> _JOEL: My greetings to you all.
How is your research going?_
Slow and steady.

---

## October 18, 2026

[10:39 AM] **ArRazaq.:**
> _ArRazaq.: We would be having our next meeting by God's Grace on Monday..

and it's more of a assignment of roles and immediately kick-starting working on the project than a meeting.

 (we need to finalize the name of the project ver 1 and our team's name) @all 

Let's build something great guys!💫_
We got a meeting on Monday @all

[10:44 AM] **ArRazaq.:** **Poll: What time should the avengers 🦈 assemble?**
- 10:00am ⏰
- 2:00pm 🗜️
- 5:00pm 🤖
- (5:00-8:00)pm ♻️
- 10:00pm 🫪

[10:46 AM] **ArRazaq.:**
> _ArRazaq.: [poll_creation]_
@ZXCHAM @JOEL @Katim@~Time @myself @all

[11:54 AM] **You:**
> _ArRazaq.: @ZXCHAM @JOEL @Katim@~Time @myself @all_
@myself kuma?😭😂

[11:57 AM] **Katim:**
> _You: @myself kuma?😭😂_
Involve me na

[12:00 PM] **You:**
> _Katim: Involve me na_
[Sticker]

[3:46 PM] **ArRazaq.:** > What would be covered on Monday:

1. What demonstrated features should the prototype have ?⚡⚡

2. What programming languages, frameworks, simulators should be used ? ♻️🤖

3. *Project prototyping workflow*🪜

4. Roles delegation🍭

5. Immediate Start🐆💀

[3:46 PM] __[System notification]__

[3:47 PM] __[System notification]__

[3:52 PM] **ArRazaq.:** _This message was deleted_

[4:09 PM] **ArRazaq.:** From My findings;

> Aqua farm is a platform used to simulate fish In fish pond/tank we can pull the data from the simulation using API and connect the virtual circuit to react and send Intel to the web app.🙂

> Secondly as I have stated alot of times it's not necessary about complexity when it comes to winning hackathons, those people know we're students and broke 😂, 

> they would not expect us to show them a full web app with multiple interfaces/logins captcha verification from day 1, 

> we frame it like when we get the grant we would be able to scale the product and also intentionally mention that the prototype does not demonstrate all features of the core product 

> because we prioritize the most vital and easily demonstrable features (This would make them know that we have a bigger plan and are serious with scalling)

Also we're going to have to get about 3 fish farmers on video and do a quick interview asking them key questions that make our idea look attractive, though this is really not the phase we're in for now

We'd also make a video max 1:30 mins of maybe like 2 of us talking about the project with the fish farmer video, it's an edited video, while still talking the video would show fish swimming and then transition to a farmer , it's aura farming Sha with background music, don't worry about these guys I know a guy 🙂

Last point as to get more coverage the people with web skills would immediately start working on the web , while those with embedded skills focus on the hardware, those with both skills would help connect them together 🦈

We would share an email/GitHub so that we can work together simultaneously without having a fellow engineer sending you the raw file to edit.

[4:45 PM] **ArRazaq.:** _Waiting for this message. This may take a while._

[6:16 PM] **You:**
> _ArRazaq.: Video_
[Sticker]

[6:46 PM] **ArRazaq.:**
> _You: Sticker_
[Sticker]

---

## October 19, 2026

[10:10 AM] **ArRazaq.:**
> _ArRazaq.: [poll_creation]_
5:00 pm it is then , hope we'll @all  make it 🦈💡

[10:13 AM] **You:**
> _ArRazaq.: 5:00 pm it is then , hope we'll @all  make it 🦈💡_
We actiff⚡

[1:58 PM] **+234 806 158 8349:** Good afternoon guys
I don't think I'll be able to join today's meeting 
Still trying to get accommodation

[2:04 PM] **Katim:**
> _+234 806 158 8349: Good afternoon guys
I don't think I'll be able to join today's meeting 
Still trying to get accommodation_
Has the portal opened for us?

[5:18 PM] **ArRazaq.:** Good evening @all

[5:19 PM] **ArRazaq.:** Avengers assemble 
@all

[5:19 PM] **ArRazaq.:** Sorry for coming late I was busy with smt

[5:19 PM] **ArRazaq.:** Should we do a call or a normal chat ?

[5:22 PM] **JOEL:** Sorry, I was also late.
Let's Proceed.

[5:23 PM] **ArRazaq.:** > What would be covered on Monday:

1. What demonstrated features should the prototype have ?⚡⚡

2. What programming languages, frameworks, simulators should be used ? ♻️🤖

3. *Project prototyping workflow*🪜

4. Roles delegation🍭

5. Immediate Start🐆💀

[5:23 PM] __[System notification]__

[5:24 PM] **ArRazaq.:** The rest are not here so let's discuss on text for now

[5:24 PM] **ArRazaq.:**
> _ArRazaq.: > What would be covered on Monday:

1. What demonstrated features should the prototype have ?⚡⚡

2. What programming languages, frameworks, simulators should be used ? ♻️🤖

3. *Project prototyping workflow*🪜

4. Roles delegation🍭

5. Immediate Start🐆💀_
This is what would be covered in today's meeting

[5:27 PM] **ArRazaq.:** First of I want to commend you all for you're commitment, making time/brainstorming I see the efforts made.

[5:28 PM] **ArRazaq.:** Now back to it, we cannot make the full product for the hackathon only a tentative demo

So our project is a Smart fishing system ( web app + iot devices)

[5:30 PM] **ArRazaq.:** What stuff should our demo have, in my opinion they are threevhigh yield features we should demonstrate 

1. Vet access 
2. Simulated Alert when oxygen level is low ( on WhatsApp/phone notification without internet)
3. AI advisor

[5:35 PM] **JOEL:** Could you elaborate on your view? And what do you mean by "...tentative demo."?

[5:36 PM] **ArRazaq.:**
> _JOEL: Could you elaborate on your view? And what do you mean by "...tentative demo."?_
By tentative demo I mean a demonstration of highly attractive features of our project, so that judges interest would be peaked rather than showing them every possible feature

[5:40 PM] **ArRazaq.:** The web app should have a dashboard where a fish farmer can login/sign up , here are the core features I strongly believe would be best

1. Once logged they tick if they are beginner/ intermediate farmers if beginners the ai would be promoted to guide them (holding their hands)
2. A place for them to tick if they have access to a device module so that the app can connect with the device (optional)
3. A place for them to get ai vet advice and professional veterinary services

[5:42 PM] **ArRazaq.:** Also we would pull data from an external pond simulator and reference it to our circuit depending on the data an output is sent

[5:43 PM] **ArRazaq.:** Since we are not all present the meeting would be postponed to tomorrow @all  peace

[5:49 PM] **You:** Heyy guys sorry I'm late🥲

[5:50 PM] **You:** I made some project research proposals ahead of time sha I'll send them in a bit

[5:52 PM] **JOEL:** If I got you correctly;
The targetted users of the web app are not the technical operators, but the aquatic farmers. Also, the most essential part of the web app is the oxygen level detection which the farmers need to access vía the login/signup page. 
The web app is basically an application software that measures oxygen levels in real-time for the aquatic farmers.

[5:53 PM] **JOEL:** Just to clarify.

[5:54 PM] **You:** https://notebooklm.link.google/XXhlXm6t2iGg

[5:54 PM] **You:**
> _You: https://notebooklm.link.google/XXhlXm6t2iGg_
You guys can request for access

[6:02 PM] **JOEL:**
> _You: You guys can request for access_
I see a good list of interesting stories.
What does it entail?

[6:02 PM] **You:** I can't grant access so I'll just send the files direct

[6:03 PM] **You:**
> _JOEL: I see a good list of interesting stories.
What does it entail?_
Those are just published by google

[6:03 PM] **You:** My notebooks can't grant access idk why

[6:03 PM] **You:** I made one for this project

[6:07 PM] **JOEL:** Hmm, Okay,
That's great!
I would like to see it, but you can't grant access to it.
You could search ways to do that.

[6:09 PM] **You:** It's probably a server thing 
It keeps saying failed to grant access

[6:10 PM] **You:** [Document] Intelligent_Fish_Farming_Ecosystem_Technical_Proposal.pdf

[6:10 PM] **You:** [Document] Intelligent_Aquaculture_Backend.pdf

[6:10 PM] **You:** [Document] Smart_Aquaculture_Blueprint.pdf

[6:10 PM] **You:** These are more of technical specs so they don't cover every single thing sha

[6:12 PM] **You:**
> _You: Document: Intelligent_Fish_Farming_Ecosystem_Technical_Proposal.pdf_
There are some artifacts though due to the formatting 🫠
Stuff like $/frac$

[6:21 PM] **JOEL:**
> _You: It's probably a server thing 
It keeps saying failed to grant access_
It happens sometimes.

[6:21 PM] **You:** This one that almost everyone is offline

[6:31 PM] **JOEL:**
> _You: Document: Smart_Aquaculture_Blueprint.pdf_
From what I see in those documents.
I must express that it is a great one!
The architecture or work flow is solid.
The metrics is also nice.
You also imcluded the economics of the project. Great!
I see you're planning on using Node.js for backend development. What about Python?
Also, in my opinion, SQLite cannot handle large data simulataneously.
PostgreSQL is more efficient for a database plan.
 If it was not a web app for all Farmers willing to apply, I would say that SQLite may be fine.
All together.
You have a detailed research right there!

[6:32 PM] **JOEL:**
> _You: This one that almost everyone is offline_
Well, Maybe everyone is currently occupied!

[7:38 PM] **ArRazaq.:** [Sticker]

[7:52 PM] **ArRazaq.:**
> _You: Document: Smart_Aquaculture_Blueprint.pdf_
Appreciated

[7:57 PM] **You:**
> _JOEL: From what I see in those documents.
I must express that it is a great one!
The architecture or work flow is solid.
The metrics is also nice.
You also imcluded the economics of the project. Great!
I see you're planning on using Node.js for backend development. What about Python?
Also, in my opinion, SQLite cannot handle large data simulataneously.
PostgreSQL is more efficient for a database plan.
 If it was not a web app for all Farmers willing to apply, I would say that SQLite may be fine.
All together.
You have a detailed research right there!_
[Sticker]

[7:57 PM] **You:**
> _ArRazaq.: Appreciated_
[Sticker]

[7:57 PM] **You:**
> _JOEL: Well, Maybe everyone is currently occupied!_
Chim

[8:33 PM] **Katim:** So we should shift the meeting tomorrow. A time where we would all be available because we can't conclude without everyone being present.
We are equally important to make any decisions.
This meeting isn't different.

[8:34 PM] **ArRazaq.:**
> _Katim: So we should shift the meeting tomorrow. A time where we would all be available because we can't conclude without everyone being present.
We are equally important to make any decisions.
This meeting isn't different._
Shit the meeting?

[8:34 PM] **ArRazaq.:** [Sticker]

[8:35 PM] **Katim:**
> _ArRazaq.: Shit the meeting?_
Correct sir

[8:36 PM] **ArRazaq.:**
> _Katim: So we should shift the meeting tomorrow. A time where we would all be available because we can't conclude without everyone being present.
We are equally important to make any decisions.
This meeting isn't different._
Agreed but we don't have a lot of time deadline is Nov 13 @all

[8:37 PM] **Katim:**
> _ArRazaq.: Agreed but we don't have a lot of time deadline is Nov 13 @all_
That's why we need to have this meeting tomorrow.

[8:39 PM] **ArRazaq.:** **Poll: What time should the avengers assemble? 🦈💻🦾**
- 8:00am -
- 10:00am -
- 2:00pm -
- 5:00pm -
- 9:00pm -

[8:42 PM] **ArRazaq.:** I don't mind if we all can be present today 10pm for the meeting

[8:43 PM] **+234 806 158 8349:**
> _Katim: Has the portal opened for us?_
Not yet
But we were chased from the hostel so i had to look for a place in Bk to stay

[8:44 PM] **ArRazaq.:**
> _+234 806 158 8349: Not yet
But we were chased from the hostel so i had to look for a place in Bk to stay_
Sorry about that

[8:45 PM] **Katim:**
> _+234 806 158 8349: Not yet
But we were chased from the hostel so i had to look for a place in Bk to stay_
Omo 
Sorry about that.

[8:46 PM] **You:**
> _+234 806 158 8349: Not yet
But we were chased from the hostel so i had to look for a place in Bk to stay_
[Sticker]

[8:49 PM] **+234 806 158 8349:** All gud

[8:50 PM] **ArRazaq.:** Since we are turning up could we have the meeting today I'll call @JOEL and tell him to come online

[8:50 PM] **ArRazaq.:** @all

[8:52 PM] **+234 806 158 8349:** Suggest it be tomorrow 
Probably in the evening

[9:03 PM] __[System notification]__

---

## October 20, 2026

[2:19 PM] **Katim:** [Image]

[2:19 PM] **Katim:** [Image]

[2:19 PM] **Katim:** [Image]

[2:20 PM] **Katim:** We will have to make improvements on what exists already

[2:38 PM] **ArRazaq.:**
> _Katim: We will have to make improvements on what exists already_
Ofc

[2:45 PM] **ArRazaq.:** Facebook was not the first platform of it's kind that came out, it did something critical previous platforms didn't (speed, easier to use)

[2:49 PM] **ArRazaq.:** Those already existing smart ponds are mostly imported from abroad hence the huge cost and why only 33.3% of fish farmers in Nigeria actually have a pH monitor for their pond.

And compared to Nigeria those counties have seemingly better internet, which is why the devices are built to reflect that

There are a lot of problems to exploit

[4:05 PM] **ArRazaq.:** Almost time Dawgs @all

[4:32 PM] **You:** [Sticker]

[4:56 PM] **ArRazaq.:** [GIF]

[4:56 PM] **ArRazaq.:** @all

[4:57 PM] __[Call]__

[4:57 PM] __[Call]__

[4:59 PM] **You:**
> _ArRazaq.: Video_
[Sticker]

[5:01 PM] __[Call]__

[5:03 PM] **ArRazaq.:** > What would be covered on Monday:

1. What demonstrated features should the prototype have ?⚡⚡

2. What programming languages, frameworks, simulators should be used ? ♻️🤖

3. *Project prototyping workflow*🪜

4. Roles delegation🍭

5. Immediate Start🐆💀

[6:38 PM] **You:** _Waiting for this message. This may take a while._

[6:38 PM] **You:**
> _You: Image_
On some aboki startup vibes

[6:39 PM] **Katim:** Abeg o
Not Aboki

[6:40 PM] **JOEL:** Give it a compelling name, not one that even at sight disgust the Judges.

[6:41 PM] **+234 806 158 8349:** 🤔
I think we should ponder on it a bit

[6:46 PM] **You:**
> _+234 806 158 8349: 🤔
I think we should ponder on it a bit_
Yh

[7:39 PM] **ArRazaq.:**
> _JOEL: Give it a compelling name, not one that even at sight disgust the Judges._
XD

[7:39 PM] **ArRazaq.:**
> _You: Image_
No

[7:39 PM] **ArRazaq.:**
> _+234 806 158 8349: 🤔
I think we should ponder on it a bit_
Team Name
1. Tech sharks 
2. BlueMech
3. Aqua Forge 
4. MechaMarine

Project name
1. PondLens
2. Fish Sentry (FS)
3. FinFarmTech (FFT)
4. Aqua harvest (AH)
5. Auto Aqua

[7:39 PM] **ArRazaq.:**
> _You: Image_
Please send the email

[7:45 PM] **You:**
> _ArRazaq.: No_
Ik just playing around

[7:45 PM] **You:**
> _ArRazaq.: Please send the email_
Send me your github email

[7:45 PM] **You:**
> _You: Send me your github email_
Or username

---

## October 31, 2026

[10:45 PM] **ArRazaq.:**
> _ArRazaq.: email: techsharks.team@gmail.com 

password: kifiguard_
https://velxio.dev/project/e8be0f9a-1d80-4a08-a75e-8a39c2ca85d2

Please someone help me wire this.

[10:46 PM] **Katim:**
> _+234 806 158 8349: Sorry I've not been online
Which is that?_
Don't worry.
It's showing now

[11:19 PM] **Katim:** [Image] Im trying to update it

[11:21 PM] **ArRazaq.:**
> _Katim: Image: Im trying to update it_
Did it work?

[11:21 PM] **Katim:** No

[11:21 PM] **Katim:** It's still showing forbidden with the new email

[11:22 PM] **ArRazaq.:**
> _Katim: It's still showing forbidden with the new email_
Hmmm ok no problem let me see

[11:24 PM] **ArRazaq.:** Ok refresh the page and try it now

[11:25 PM] **Katim:** Same thing

[11:26 PM] **ArRazaq.:**
> _Katim: Same thing_
Alright thanks

[11:28 PM] **Katim:**
> _ArRazaq.: Alright thanks_
So what is it going to be now

[11:28 PM] **ArRazaq.:**
> _Katim: So what is it going to be now_
You've wired right, we'll use you're version

[11:47 PM] **ArRazaq.:** Nvm no whams I'll handle it

[11:47 PM] **ArRazaq.:** We would do the coding together Sha BGG

---

## November 1, 2026

[8:19 AM] **ArRazaq.:** [Document] fish_pond-live.html

[8:24 AM] **ArRazaq.:**
> _ArRazaq.: Document: fish_pond-live.html_
Update the frontend repo for the fish pond simulation

[8:36 AM] **Katim:**
> _ArRazaq.: We would do the coding together Sha BGG_
Have you connected it?

[8:39 AM] **Katim:**
> _ArRazaq.: Document: fish_pond-live.html_
Explain this sim the pH seems not to be changing

[9:00 AM] **ArRazaq.:**
> _Katim: Have you connected it?_
Yh

[9:00 AM] **ArRazaq.:**
> _Katim: Explain this sim the pH seems not to be changing_
We would vary the stuff from the sensors

[7:01 PM] **ArRazaq.:**
> _Katim: So what is it going to be now_
Try using you're laptop just make a small change like a comment in the code and try to save

[7:01 PM] **ArRazaq.:** Also go to file and select my projects then you'll see it

[8:28 PM] **ArRazaq.:** Hey guys check this out

https://velxio.dev/project/b58131c4-52ca-44b8-b82b-2df329d7b43b

Run the simulation and press a sensor..once you do you'll see a slider to vary the values


This is the fish simulation we would embed in the web app

catfish-pond-2.vercel.app

I recommend you open the simulation on a separate device while the hardware would be on you're phone...refresh if it doesn't connect

[8:57 PM] **ArRazaq.:** Used MQTT and a topic... Backend Dawgs feel free to ask for info concerning the frontend, we sent the sensors data through MQTT it prints Json type shi like "p,b,c" and in the code I set those variables to the sensors anolog values..

[9:08 PM] **ArRazaq.:** _Waiting for this message. This may take a while._

[9:51 PM] **You:**
> _ArRazaq.: Used MQTT and a topic... Backend Dawgs feel free to ask for info concerning the frontend, we sent the sensors data through MQTT it prints Json type shi like "p,b,c" and in the code I set those variables to the sensors anolog values.._
Aiit

[11:19 PM] **Katim:**
> _ArRazaq.: Try using you're laptop just make a small change like a comment in the code and try to save_
My laptop WhatsApp is out of date

[11:20 PM] **ArRazaq.:**
> _Katim: My laptop WhatsApp is out of date_
No you don't need to use WhatsApp just go to velxio.dev sign in with tech sharks and press the profile icon and select "my projects" and you'll see what's happening

[11:47 PM] **Katim:**
> _ArRazaq.: Hey guys check this out

https://velxio.dev/project/b58131c4-52ca-44b8-b82b-2df329d7b43b

Run the simulation and press a sensor..once you do you'll see a slider to vary the values


This is the fish simulation we would embed in the web app

catfish-pond-2.vercel.app

I recommend you open the simulation on a separate device while the hardware would be on you're phone...refresh if it doesn't connect_
Have they been connected together? In the sense that varying a value in the hardware gives a response in the simulation

---

## November 2, 2026

[12:10 AM] **Katim:**
> _ArRazaq.: No you don't need to use WhatsApp just go to velxio.dev sign in with tech sharks and press the profile icon and select "my projects" and you'll see what's happening_
I can see that if just the hardware what about the simulation

[8:30 AM] **ArRazaq.:**
> _Katim: Have they been connected together? In the sense that varying a value in the hardware gives a response in the simulation_
Yes

[8:30 AM] **ArRazaq.:** Don't join us be sleeping at night 🥲

[8:31 AM] **ArRazaq.:**
> _Katim: I can see that if just the hardware what about the simulation_
The simulation you search for


catfish-pond-2.vercel.app

[8:32 AM] **Katim:**
> _ArRazaq.: Don't join us be sleeping at night 🥲_
This is harsh

[8:33 AM] **Katim:**
> _ArRazaq.: The simulation you search for


catfish-pond-2.vercel.app_
Haba I have seen this before na 🥺

[9:22 AM] **ArRazaq.:** Press play button when you go to code on velxio....on the other device open the catfish-pond-2.vercel.app

[11:41 AM] **JOEL:** Good morning @all

[11:42 AM] **JOEL:**
> _ArRazaq.: @JOEL or @Katim please help me to connect the wires , we'll work on the code together_
Sorry. I haven't been active for a while.

[11:45 AM] **JOEL:**
> _ArRazaq.: email: techsharks.team@gmail.com 

password: kifiguard_
This the login details to access the current hardware project on Velxio, right?

[11:55 AM] **JOEL:**
> _ArRazaq.: Press play button when you go to code on velxio....on the other device open the catfish-pond-2.vercel.app_
For this to be working, that means you already created a small backend file (.py or other formats). Is it the backend code currently in the remote repository or the one you created.
I ask this because Astro Is in charge of the backend, and there should be active communication to see how well the backend can be integrated with the hardware (readings) for easy computation and display.

[12:06 PM] **JOEL:**
> _+234 806 158 8349: Video_
I love the design.
Great work!
To understand it more, 
Does the web app store those login details, and where would the simulation environment, one that AbdulRazak is doing, be located?

[12:28 PM] **ArRazaq.:**
> _JOEL: For this to be working, that means you already created a small backend file (.py or other formats). Is it the backend code currently in the remote repository or the one you created.
I ask this because Astro Is in charge of the backend, and there should be active communication to see how well the backend can be integrated with the hardware (readings) for easy computation and display._
No you don't need backend just server for communication we can do backend for logging time of events and more complex info

[12:32 PM] **ArRazaq.:** Yes the web app stores the login data, @Time please where can we embed the simulation

[12:52 PM] **+234 806 158 8349:** Been waiting for u guys to mention

I recommend giving the simulation its own page under My Farms, rather than placing it directly on the dashboard.
If that's alright i can start working on that

[1:10 PM] **JOEL:**
> _ArRazaq.: No you don't need backend just server for communication we can do backend for logging time of events and more complex info_
I understand.
There should be a central let's say Python file that communicates with the ESP hardware code, gets the readings, causes a display of the varying data in real time, prompts a message when a reading is approaching a hardcoded threshold and more. Then there could be some sub python files that communicate with the central python file, and handles some other minor tasks (like one that communicates with the AI models through API keys for customer supports and guidance). 
So if you built that fish simulation alone, then you must have included a python file, Also, @~Time frontend may have used a python file for redirection between pages once a button or card is clicked.
We just need something like a main.py (central python file) that does the simulation operations, and other sub.py for other tasks.

[1:13 PM] **JOEL:**
> _+234 806 158 8349: Been waiting for u guys to mention

I recommend giving the simulation its own page under My Farms, rather than placing it directly on the dashboard.
If that's alright i can start working on that_
Great!
There could also be a small and clear message sonewhere in the dashboard that should inform and guide the user to the simulation environment.

[1:13 PM] **ArRazaq.:**
> _+234 806 158 8349: Been waiting for u guys to mention

I recommend giving the simulation its own page under My Farms, rather than placing it directly on the dashboard.
If that's alright i can start working on that_
Ok that's good

[1:14 PM] **ArRazaq.:**
> _JOEL: Great!
There could also be a small and clear message sonewhere in the dashboard that should inform and guide the user to the simulation environment._
The simulation environment is just for the demo when we're demonstrating live

[1:15 PM] **JOEL:**
> _ArRazaq.: The simulation environment is just for the demo when we're demonstrating live_
Sorry, I didn't get that.

[1:15 PM] **JOEL:** What demo?

[1:19 PM] **ArRazaq.:** The judges would ask us for a demonstration of what we're pitching, we use the fish simulation as a means to show them what our hardware -software system behaves like

[1:19 PM] **ArRazaq.:** The finished product would not have a simulation

[1:25 PM] **ArRazaq.:**
> _+234 806 158 8349: Been waiting for u guys to mention

I recommend giving the simulation its own page under My Farms, rather than placing it directly on the dashboard.
If that's alright i can start working on that_
[Document] Sauce code

[1:28 PM] **JOEL:** I thought the whole point of the project was the simulation.
It is called simulation to us, but will be referred to as an indicator or means of measuring the current state of the Farmer's aquatic lives in real time via a web app.

[1:29 PM] **JOEL:**
> _ArRazaq.: The finished product would not have a simulation_
What then is the finished product, and what would it contain?

[1:34 PM] **ArRazaq.:**
> _JOEL: What then is the finished product, and what would it contain?_
It's the hardware components itself connected to the web app

[1:45 PM] **JOEL:** I also want to point out something:
We are connecting sensors to our apps through the backend, and eventually we hope it works.
Is that how the users are also going to buy physical sensors( turbidity, oxygen, and other), and then attach it to their pond to use our simulator? It is possible.
Are they also going to go through the process of modifying the backend to cause their sensors of different manufacturers to work seamlessly with our app.
If buying sensors and controllers (ESP) would be possible, then I believe there should be a way our web app could receive the sensor's  reading directly over WIFI or Bluetooth if possible, and not with repetitive backend modification. All these could be done with the push of a button called "Connect to microcontroller or device" in the web app.
My Observations

[3:06 PM] **ArRazaq.:**
> _JOEL: I also want to point out something:
We are connecting sensors to our apps through the backend, and eventually we hope it works.
Is that how the users are also going to buy physical sensors( turbidity, oxygen, and other), and then attach it to their pond to use our simulator? It is possible.
Are they also going to go through the process of modifying the backend to cause their sensors of different manufacturers to work seamlessly with our app.
If buying sensors and controllers (ESP) would be possible, then I believe there should be a way our web app could receive the sensor's  reading directly over WIFI or Bluetooth if possible, and not with repetitive backend modification. All these could be done with the push of a button called "Connect to microcontroller or device" in the web app.
My Observations_
[Sticker]

[3:16 PM] **ArRazaq.:**
> _ArRazaq.: Document: Sauce code_
@ZXCHAM

[3:41 PM] **You:**
> _ArRazaq.: Document: Sauce code_
[Sticker]

[3:50 PM] **Katim:**
> _JOEL: I also want to point out something:
We are connecting sensors to our apps through the backend, and eventually we hope it works.
Is that how the users are also going to buy physical sensors( turbidity, oxygen, and other), and then attach it to their pond to use our simulator? It is possible.
Are they also going to go through the process of modifying the backend to cause their sensors of different manufacturers to work seamlessly with our app.
If buying sensors and controllers (ESP) would be possible, then I believe there should be a way our web app could receive the sensor's  reading directly over WIFI or Bluetooth if possible, and not with repetitive backend modification. All these could be done with the push of a button called "Connect to microcontroller or device" in the web app.
My Observations_
Please use voice note to explain.
Im getting the picture of what you are saying at the surface. It's not really clear

[4:49 PM] **ArRazaq.:**
> _JOEL: I also want to point out something:
We are connecting sensors to our apps through the backend, and eventually we hope it works.
Is that how the users are also going to buy physical sensors( turbidity, oxygen, and other), and then attach it to their pond to use our simulator? It is possible.
Are they also going to go through the process of modifying the backend to cause their sensors of different manufacturers to work seamlessly with our app.
If buying sensors and controllers (ESP) would be possible, then I believe there should be a way our web app could receive the sensor's  reading directly over WIFI or Bluetooth if possible, and not with repetitive backend modification. All these could be done with the push of a button called "Connect to microcontroller or device" in the web app.
My Observations_
Ok I think I get what you're saying I've thought about that too

[4:50 PM] **ArRazaq.:** So if a farmer already has a oxygen sensor instead of modifying the backend there should be a place for them to connect instead of buying our own sensor newly

[5:28 PM] **JOEL:** [Voice message]

[5:40 PM] **ArRazaq.:**
> _JOEL: Voice message_
[Sticker]

[5:56 PM] **ArRazaq.:**
> _JOEL: Voice message_
[Voice message]

[6:50 PM] **ArRazaq.:** [Voice message]

[8:35 PM] **JOEL:**
> _ArRazaq.: Voice message_
It's alright
Let's see how it goes.

[8:36 PM] **JOEL:** I have update our Velxio project, but I haven't finished it yet.
I should be able to finish it tomorrow.

[8:44 PM] **ArRazaq.:** Ok did you add comment saying what you updated?

---

## November 3, 2026

[11:30 AM] **JOEL:** Yes

[11:48 AM] **JOEL:** I see that even after saving the updated project on Velxio, I can't find it anywhere. It still shows me the state of the project before the change.

[11:52 AM] **ArRazaq.:**
> _JOEL: I see that even after saving the updated project on Velxio, I can't find it anywhere. It still shows me the state of the project before the change._
Press the account icon and go to my projects

[11:57 AM] **ArRazaq.:** [Video]

[12:02 PM] **Katim:**
> _JOEL: Voice message_
[Voice message]

[12:04 PM] **Katim:**
> _ArRazaq.: Voice message_
Exactly 👍💯

[5:55 PM] **JOEL:**
> _Katim: Voice message_
It's fine.
I understand your views.
Let's just proceed with the project. My view may be a later means of optimizing it.

[6:06 PM] **ArRazaq.:**
> _JOEL: It's fine.
I understand your views.
Let's just proceed with the project. My view may be a later means of optimizing it._
Have loaded the updated project

[6:07 PM] **ArRazaq.:**
> _ArRazaq.: Video_
Use this vid, if you opened the project with the old link you'd see the old set-up...

[6:18 PM] **JOEL:** https://docs.google.com/forms/d/e/1FAIpQLScdM-x7BUF7p6HSHJMb3sZbRJJeanbPRZHTXs_6QF1HJRqP3w/viewform

[6:20 PM] **JOEL:** No,
All of my changes are gone.
I would have start over again only when I am sure it will not act the same way again

[6:33 PM] **ArRazaq.:** Can you explain to me how you opened it ? Did you use the old link ?

[6:41 PM] **JOEL:** Well, I used this link:

https://velxio.dev/project/e8be0f9a-1d80-4a08-a75e-8a39c2ca85d2

It then redirected me to the project. I signed in using the details given, and  made some changes to it. I tried to save, but it displayed "Forbidden". I then used a different window, and it worked (SAVED). 

I tried opening it today only for me to find out that all changes are gone.
It's alright.

[6:45 PM] **ArRazaq.:**
> _JOEL: Well, I used this link:

https://velxio.dev/project/e8be0f9a-1d80-4a08-a75e-8a39c2ca85d2

It then redirected me to the project. I signed in using the details given, and  made some changes to it. I tried to save, but it displayed "Forbidden". I then used a different window, and it worked (SAVED). 

I tried opening it today only for me to find out that all changes are gone.
It's alright._
Ok great you used you're phone the first time right?

And you have to open it directly you don't open it from the old link 


https://velxio.dev/project/e8be0f9a-1d80-4a08-a75e-8a39c2ca85d2

There's currently no project existing with this link

[6:47 PM] **ArRazaq.:** [album message]

[6:47 PM] **ArRazaq.:** [Image]

[6:47 PM] **ArRazaq.:** [Image]

[6:49 PM] **ArRazaq.:** Use Desktop/laptop the only one who can use phone is the person who logged into the account with phone

---

## November 4, 2026

[10:25 AM] **ArRazaq.:** @JOEL I just checked the schools desktop and I see that you're work actually saved

[10:25 AM] **ArRazaq.:** [Video]

[4:43 PM] **JOEL:** Yes, Thanks to you.
So I have done a little bit of work on the debug copy. I saved it as debug_updated.
I separated the Acidity and Basicity level so they both show critical at 0 and 14. But due to the limitations in the wirings/connections, the voltage/analog values aren't reaching 0 to 3.3V OR 0 to 4095 bits.

[4:44 PM] **JOEL:** They fall in between

[4:48 PM] **ArRazaq.:** Ok great thanks

[5:59 PM] **ArRazaq.:** About that if the calibration is still off somehow..go to maximum of the PH slider and see what is on the serial monitor..set PH-RAW-HIGH to equal it...and do the same for the Lowest that'll fix it

[6:00 PM] **ArRazaq.:** Who wants to volunteer their phone number for the sms/WhatsApp messaging ?

---

## November 5, 2026

[11:36 AM] **ArRazaq.:** [Sticker]

[11:36 AM] **ArRazaq.:** 8 days left to deadline

[11:36 AM] **You:**
> _ArRazaq.: 8 days left to deadline_
[Sticker]

[11:51 AM] **ArRazaq.:** @Katim you're the lead founder

[1:22 PM] **ArRazaq.:**
> _ArRazaq.: Who wants to volunteer their phone number for the sms/WhatsApp messaging ?_
I'm going to work on this

[3:46 PM] **JOEL:**
> _ArRazaq.: About that if the calibration is still off somehow..go to maximum of the PH slider and see what is on the serial monitor..set PH-RAW-HIGH to equal it...and do the same for the Lowest that'll fix it_
Great!

[3:52 PM] **ArRazaq.:**
> _ArRazaq.: Document: Sauce code_
This is the sauce code for the simulation..@~Time remove the head,body tag and put everything into a div tag and add it on the web app please,

@ZXCHAM the web app pulls data from the hardware so the backend should also store the data so that the time it happened is displayed and it goes to the frontend farmers dashboard history.

The backend is just connecting the web app to a database so that different users can sign up and settings they set would be saved ... nothing much the simulation is already pretty much setup...the thing I'm thinking about is sms message simulation.

If you guys need assistance feel free to ask

[3:52 PM] **ArRazaq.:** Also we're doing a 60s video to attach to the application 

1. Story 10s
2. Innovation/project 25s
3. Fish farmers validating/fish related experts validating the product 23s
4. Closing 2secs

Background music: inspirational type shi 

Staring 3 of us with one person being the main voice of the video the other two would be in a scene where we are scene coding the hardware/software

[3:52 PM] **ArRazaq.:** Also going to work on PowerPoint slides

[3:53 PM] **ArRazaq.:**
> _JOEL: Great!_
[Sticker]

[6:59 PM] **JOEL:**
> _ArRazaq.: Also we're doing a 60s video to attach to the application 

1. Story 10s
2. Innovation/project 25s
3. Fish farmers validating/fish related experts validating the product 23s
4. Closing 2secs

Background music: inspirational type shi 

Staring 3 of us with one person being the main voice of the video the other two would be in a scene where we are scene coding the hardware/software_
Well said!

[7:14 PM] **JOEL:** I have been able to debug the analog and unit calibration.  So you guys can check it out.
Project Name: "debug_updated"
I noticed a limitation in the simulation, and I believe @ArRazaq. should be able to sort that out.
I saw that Too much oxygen (CRITICAL) causes the fish to die rapidly.
In the real world, too much oxygen shouldn't kill those fish so rapidly, and excess oxygen naturally escapes from the water surface enough to balance out the effect.

[8:22 PM] **ArRazaq.:**
> _JOEL: I have been able to debug the analog and unit calibration.  So you guys can check it out.
Project Name: "debug_updated"
I noticed a limitation in the simulation, and I believe @ArRazaq. should be able to sort that out.
I saw that Too much oxygen (CRITICAL) causes the fish to die rapidly.
In the real world, too much oxygen shouldn't kill those fish so rapidly, and excess oxygen naturally escapes from the water surface enough to balance out the effect._
Ok I'll handle that

---

## November 6, 2026

[10:48 AM] **ArRazaq.:** _Waiting for this message. This may take a while._

[10:48 AM] **ArRazaq.:** Just generated this reference..the backend would be used to send the sms as i don't think velxio as a sim card module...im still going to work on the pond html in the static so too much oxygen forms bubbles on their gills and eyes and mouth and slowly suffocates them

[10:49 AM] **ArRazaq.:**
> _ArRazaq.: Document: fishpond_flask.zip_
@ZXCHAM

[10:49 AM] **ArRazaq.:** @~Time please send astro the raw file for the web app or push it to the repository

[11:10 AM] **ArRazaq.:**
> _ArRazaq.: Just generated this reference..the backend would be used to send the sms as i don't think velxio as a sim card module...im still going to work on the pond html in the static so too much oxygen forms bubbles on their gills and eyes and mouth and slowly suffocates them_
[Document] fishpond_flask.zip

[12:47 PM] **+234 806 158 8349:**
> _ArRazaq.: @~Time please send astro the raw file for the web app or push it to the repository_
Would do that by tomorrow
Still finishing up and correcting some errors

[12:47 PM] **ArRazaq.:** [Image]

[1:03 PM] **You:**
> _ArRazaq.: @ZXCHAM_
Aiit

[1:03 PM] **You:**
> _ArRazaq.: Image_
We can do a short demo of the software and simulation in action

[1:04 PM] **ArRazaq.:**
> _You: We can do a short demo of the software and simulation in action_
Yh thought about that too

[1:06 PM] **ArRazaq.:**
> _+234 806 158 8349: Video_
[Image]

[1:07 PM] **ArRazaq.:**
> _+234 806 158 8349: Would do that by tomorrow
Still finishing up and correcting some errors_
Ok 👌🏼

[1:41 PM] **ArRazaq.:** _Waiting for this message. This may take a while._

[2:00 PM] **ArRazaq.:** https://www.tiktok.com/@ukachibenita/video/7658605347451505938?_r=1&u_code=efhdcm7h2f9jl2&preview_pb=0&sharer_language=en&_d=f56haim3j43fhf&share_item_id=7658605347451505938&source=h5_m&utm_source=copy&utm_campaign=client_share&share_link_id=cbbf66d1-771b-4a64-a795-9b2805fcd1cc&share_app_id=1340&ugbiz_name=Main&item_type=2&series_category=0&item_author_type=2&panel_source_v2=quick_share_button&user_id=7401988107162354693&sec_user_id=MS4wLjABAAAAMJ9Y37cdkhkWUuRHg5oBAY-eL2KmKgf8bmWbCSepkZFPvooyxBQ_35xMXkMFzKBz&enable_checksum=1 This post is shared via TikTok Lite. Download TikTok Lite to enjoy more posts: https://www.tiktok.com/tiktoklite

[2:00 PM] **ArRazaq.:**
> _ArRazaq.: https://www.tiktok.com/@ukachibenita/video/7658605347451505938?_r=1&u_code=efhdcm7h2f9jl2&preview_pb=0&sharer_language=en&_d=f56haim3j43fhf&share_item_id=7658605347451505938&source=h5_m&utm_source=copy&utm_campaign=client_share&share_link_id=cbbf66d1-771b-4a64-a795-9b2805fcd1cc&share_app_id=1340&ugbiz_name=Main&item_type=2&series_category=0&item_author_type=2&panel_source_v2=quick_share_button&user_id=7401988107162354693&sec_user_id=MS4wLjABAAAAMJ9Y37cdkhkWUuRHg5oBAY-eL2KmKgf8bmWbCSepkZFPvooyxBQ_35xMXkMFzKBz&enable_checksum=1 This post is shared via TikTok Lite. Download TikTok Lite to enjoy more posts: https://www.tiktok.com/tiktoklite_
[Sticker]

[2:01 PM] **ArRazaq.:**
> _ArRazaq.: https://www.tiktok.com/@ukachibenita/video/7658605347451505938?_r=1&u_code=efhdcm7h2f9jl2&preview_pb=0&sharer_language=en&_d=f56haim3j43fhf&share_item_id=7658605347451505938&source=h5_m&utm_source=copy&utm_campaign=client_share&share_link_id=cbbf66d1-771b-4a64-a795-9b2805fcd1cc&share_app_id=1340&ugbiz_name=Main&item_type=2&series_category=0&item_author_type=2&panel_source_v2=quick_share_button&user_id=7401988107162354693&sec_user_id=MS4wLjABAAAAMJ9Y37cdkhkWUuRHg5oBAY-eL2KmKgf8bmWbCSepkZFPvooyxBQ_35xMXkMFzKBz&enable_checksum=1 This post is shared via TikTok Lite. Download TikTok Lite to enjoy more posts: https://www.tiktok.com/tiktoklite_
So she's an ai engineer and she built something very similar to what we're trying to do 🙂

[2:02 PM] **ArRazaq.:** She made the ai work offline I bet she used edged ai tech..I heard about it too earlier

[5:15 PM] **You:**
> _ArRazaq.: So she's an ai engineer and she built something very similar to what we're trying to do 🙂_
[Sticker]

[5:15 PM] **You:**
> _ArRazaq.: She made the ai work offline I bet she used edged ai tech..I heard about it too earlier_
Damn

[5:57 PM] **ArRazaq.:** [Sticker]

[5:57 PM] **ArRazaq.:** This shows we shouldn't expect no competition

---

## November 9, 2026

[12:24 AM] **You:**
> _+234 806 158 8349: Would do that by tomorrow
Still finishing up and correcting some errors_
@~Time ...

[1:56 PM] **+234 806 158 8349:** Please can someone send the link to the GitHub repo

[1:58 PM] **ArRazaq.:** https://github.com/AqauSafe/frontend

[1:58 PM] **ArRazaq.:** @all

[3:16 PM] **ArRazaq.:** Good afternoon guys we would be having a physical meeting tomorrow

[3:17 PM] **ArRazaq.:** **Poll: Time ? ⌛**
- 8:30am
- 10:00am
- 12:00pm
- 2:00pm

[3:21 PM] **ArRazaq.:** **Poll: Place ? 🏠**
- Love Garden 💗🪴
- Bush-Canteen FOC(computer science faculty) 🤓💻
- FAE Classroom ✈️✈️
- Mechanical Classroom 🦾🦿

[3:21 PM] **ArRazaq.:** @all

[3:43 PM] **ArRazaq.:** OHk look forward to seeing you all there 👀

@all 

Time = 12:00pm

Venue = Love Garden

[5:54 PM] **You:** _You deleted this message_

[6:04 PM] **ArRazaq.:** @~Time as sent a pull request @ZXCHAM

[6:04 PM] **ArRazaq.:** I'm trying to fork his fork so I can update the simulation

[7:27 PM] **ArRazaq.:** @~Time did you deploy fishLink ? I wanna check it out live

[7:58 PM] __[System notification]__

[8:07 PM] **You:**
> _ArRazaq.: @~Time as sent a pull request @ZXCHAM_
[Sticker]

---

## November 10, 2026

[1:29 AM] **+234 806 158 8349:**
> _ArRazaq.: @~Time did you deploy fishLink ? I wanna check it out live_
No i haven't

[7:14 AM] **ArRazaq.:** Ok

[7:14 AM] **Katim:** We have a meeting today right?

[7:14 AM] **ArRazaq.:**
> _Katim: We have a meeting today right?_
Yes ma

[7:17 AM] **ArRazaq.:** We're meeting at love garden at 12pm @all

[7:18 AM] **ArRazaq.:** [Sticker]

[7:20 AM] **ArRazaq.:**
> _ArRazaq.: Sticker_
Why did they do Anthony Mackie like this 😂

[9:22 PM] **ArRazaq.:** Good evening guys for the pitch deck slide there's a section where we add a photo of the whole team together 🥲

[9:29 PM] **ArRazaq.:** [Document] Tech_Sharks_Pitch_Deck_Polished.pptx

[9:29 PM] **You:**
> _ArRazaq.: Good evening guys for the pitch deck slide there's a section where we add a photo of the whole team together 🥲_
[Sticker]

[9:29 PM] **You:** What's the update on your fish farmer?

[9:30 PM] **ArRazaq.:**
> _You: What's the update on your fish farmer?_
Would be meeting him tomorrow

[9:30 PM] **ArRazaq.:**
> _ArRazaq.: Document: Tech_Sharks_Pitch_Deck_Polished.pptx_
This is the pitch deck btw

[9:31 PM] **ArRazaq.:**
> _ArRazaq.: Document: Tech_Sharks_Pitch_Deck_Polished.pptx_
@all

[9:31 PM] **You:**
> _ArRazaq.: Would be meeting him tomorrow_
[Sticker]

[9:40 PM] **ArRazaq.:** Due to this we would be having another brief meeting tomorrow where we take the team pic and also @Katim I would take you're voice recording or vid ...I'm also working on the video right now 
@all

[9:42 PM] **ArRazaq.:** **Poll: What Time ?✈️**
- (10:00-10:30) am (can't be later than this as I'm expected to go to the pond early to interview)
- 🙈

[9:44 PM] **ArRazaq.:** **Poll: What venue ?**
- Luv garden
- Amoa hall
- Mechanical Lr
- FAE

[9:45 PM] **ArRazaq.:** **Poll: Where should we take the pic ?**
- Luv Garden
- Open to any other suggestion

[10:11 PM] **ArRazaq.:** We should be done with everything before or on Thursday
